/* ============================================================
   CricketVault EMS — app.js
   ============================================================ */

// ── MODAL ─────────────────────────────────────────────────────
function openModal(title, body) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = body;
    document.getElementById('modalOverlay').classList.add('show');
}
function closeModal() {
    document.getElementById('modalOverlay').classList.remove('show');
}
document.addEventListener('click', e => {
    if (e.target.id === 'modalOverlay') closeModal();
});

// ── TOAST ─────────────────────────────────────────────────────
function toast(msg, type = 'success') {
    const icons = { success: '✅', error: '❌', info: 'ℹ️' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<span>${icons[type]}</span><span>${msg}</span>`;
    document.getElementById('toastContainer').appendChild(el);
    setTimeout(() => el.style.opacity = '0', 3000);
    setTimeout(() => el.remove(), 3400);
}

// ── FETCH JSON API ────────────────────────────────────────────
async function api(endpoint, data = {}) {
    const csrfToken = document.querySelector('meta[name="csrf"]')?.content || '';
    const form = new FormData();
    form.append('csrf_token', csrfToken);
    Object.entries(data).forEach(([k, v]) => form.append(k, v));
    const res = await fetch(endpoint, { method: 'POST', body: form });
    return res.json();
}

// ── TABLE SEARCH ──────────────────────────────────────────────
function filterTable(inputEl, tbodyId) {
    const q = inputEl.value.toLowerCase();
    document.querySelectorAll(`#${tbodyId} tr`).forEach(tr => {
        const text = tr.textContent.toLowerCase();
        tr.style.display = text.includes(q) ? '' : 'none';
    });
}

// ── CONFIRM DELETE ────────────────────────────────────────────
function confirmAction(msg, callback) {
    if (confirm(msg)) callback();
}

// ── ADD EQUIPMENT (ADMIN) ─────────────────────────────────────
function showAddEquipment() {
    openModal('Add Equipment', `
        <form class="modal-form" onsubmit="submitAddEquipment(event)">
            <div class="form-row">
                <div class="form-group"><label>Equipment Name *</label><input name="name" required placeholder="e.g. Cricket Bat"></div>
                <div class="form-group"><label>Emoji Icon</label><input name="emoji" placeholder="🏏" maxlength="5"></div>
            </div>
            <div class="form-group"><label>Category *</label>
                <select name="category" required>
                    <option value="">— Select —</option>
                    <option>Batting</option><option>Fielding</option><option>Safety</option>
                    <option>General</option><option>Training</option><option>Bowling</option>
                </select>
            </div>
            <div class="form-group"><label>Description</label><textarea name="description" placeholder="Brief description..."></textarea></div>
            <div class="form-row">
                <div class="form-group"><label>Total Units *</label><input name="total_units" type="number" min="1" value="10" required></div>
                <div class="form-group"><label>Min Stock Level *</label><input name="min_stock_level" type="number" min="1" value="3" required></div>
            </div>
            <div id="equipFormError"></div>
            <button type="submit" class="btn-primary btn-block">💾 Save Equipment</button>
        </form>`);
}

async function submitAddEquipment(e) {
    e.preventDefault();
    const form = e.target;
    const data = Object.fromEntries(new FormData(form));
    data.action = 'add_equipment';
    const res = await api(BASE_URL + '/api/equipment.php', data);
    if (res.success) { toast(res.message); closeModal(); location.reload(); }
    else { document.getElementById('equipFormError').innerHTML = `<div class="form-error">${res.message}</div>`; }
}

// ── EDIT EQUIPMENT ────────────────────────────────────────────
async function showEditEquipment(id) {
    const res = await api(BASE_URL + '/api/equipment.php', { action: 'get', id });
    if (!res.success) { toast(res.message, 'error'); return; }
    const e = res.data;
    openModal('Edit Equipment', `
        <form class="modal-form" onsubmit="submitEditEquipment(event,${id})">
            <div class="form-row">
                <div class="form-group"><label>Name *</label><input name="name" value="${esc(e.name)}" required></div>
                <div class="form-group"><label>Emoji</label><input name="emoji" value="${esc(e.emoji)}" maxlength="5"></div>
            </div>
            <div class="form-group"><label>Category</label>
                <select name="category">
                    ${['Batting','Fielding','Safety','General','Training','Bowling'].map(c=>
                        `<option ${e.category===c?'selected':''}>${c}</option>`).join('')}
                </select>
            </div>
            <div class="form-group"><label>Description</label><textarea name="description">${esc(e.description||'')}</textarea></div>
            <div class="form-row">
                <div class="form-group"><label>Total Units</label><input name="total_units" type="number" min="1" value="${e.total_units}" required></div>
                <div class="form-group"><label>Min Stock Level</label><input name="min_stock_level" type="number" min="1" value="${e.min_stock_level}" required></div>
            </div>
            <div id="equipFormError"></div>
            <button type="submit" class="btn-primary btn-block">💾 Update Equipment</button>
        </form>`);
}

async function submitEditEquipment(e, id) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    data.action = 'edit_equipment'; data.id = id;
    const res = await api(BASE_URL + '/api/equipment.php', data);
    if (res.success) { toast(res.message); closeModal(); location.reload(); }
    else { document.getElementById('equipFormError').innerHTML = `<div class="form-error">${res.message}</div>`; }
}

// ── DELETE EQUIPMENT ──────────────────────────────────────────
function deleteEquipment(id) {
    confirmAction('Delete this equipment? This cannot be undone.', async () => {
        const res = await api(BASE_URL + '/api/equipment.php', { action: 'delete', id });
        if (res.success) { toast(res.message); location.reload(); }
        else toast(res.message, 'error');
    });
}

// ── MARK DAMAGED ─────────────────────────────────────────────
function showMarkDamaged(id, name, available) {
    openModal('Mark as Damaged', `
        <div class="modal-form">
            <p style="color:var(--text2);font-size:13px;margin-bottom:8px">Equipment: <b>${name}</b> &nbsp;|&nbsp; Available: <b style="color:var(--green)">${available}</b></p>
            <div class="form-group"><label>Quantity Damaged</label><input id="dmgQty" type="number" min="1" max="${available}" value="1"></div>
            <div class="form-group"><label>Reason</label><textarea id="dmgReason" placeholder="Describe the damage..."></textarea></div>
            <div id="dmgError"></div>
            <button class="btn-danger btn-block" onclick="submitDamage(${id})">🔴 Confirm Damage</button>
        </div>`);
}

async function submitDamage(id) {
    const qty = document.getElementById('dmgQty').value;
    const reason = document.getElementById('dmgReason').value;
    const res = await api(BASE_URL + '/api/equipment.php', { action: 'mark_damaged', id, quantity: qty, reason });
    if (res.success) { toast(res.message, 'info'); closeModal(); location.reload(); }
    else document.getElementById('dmgError').innerHTML = `<div class="form-error">${res.message}</div>`;
}

// ── MARK REPAIRED ─────────────────────────────────────────────
function showMarkRepaired(id, name, damaged) {
    openModal('Mark as Repaired', `
        <div class="modal-form">
            <p style="color:var(--text2);font-size:13px;margin-bottom:8px">Equipment: <b>${name}</b> &nbsp;|&nbsp; Damaged: <b style="color:var(--red)">${damaged}</b></p>
            <div class="form-group"><label>Quantity Repaired</label><input id="repQty" type="number" min="1" max="${damaged}" value="${damaged}"></div>
            <div id="repError"></div>
            <button class="btn-success btn-block" onclick="submitRepair(${id})">🟢 Confirm Repair</button>
        </div>`);
}

async function submitRepair(id) {
    const qty = document.getElementById('repQty').value;
    const res = await api(BASE_URL + '/api/equipment.php', { action: 'mark_repaired', id, quantity: qty });
    if (res.success) { toast(res.message); closeModal(); location.reload(); }
    else document.getElementById('repError').innerHTML = `<div class="form-error">${res.message}</div>`;
}

// ── RESTOCK ───────────────────────────────────────────────────
function showRestock(id, name) {
    openModal('Restock Equipment', `
        <div class="modal-form">
            <p style="color:var(--text2);font-size:13px;margin-bottom:8px">Adding stock to: <b>${name}</b></p>
            <div class="form-group"><label>Units to Add</label><input id="rstockQty" type="number" min="1" value="10"></div>
            <div class="form-group"><label>Notes (optional)</label><input id="rstockNotes" placeholder="e.g. New batch purchased"></div>
            <div id="rstockError"></div>
            <button class="btn-primary btn-block" onclick="submitRestock(${id})">📦 Add Stock</button>
        </div>`);
}

async function submitRestock(id) {
    const qty = document.getElementById('rstockQty').value;
    const notes = document.getElementById('rstockNotes').value;
    const res = await api(BASE_URL + '/api/equipment.php', { action: 'restock', id, quantity: qty, notes });
    if (res.success) { toast(res.message); closeModal(); location.reload(); }
    else document.getElementById('rstockError').innerHTML = `<div class="form-error">${res.message}</div>`;
}

// ── APPROVE / REJECT / RETURN REQUEST ────────────────────────
async function approveRequest(id) {
    const res = await api(BASE_URL + '/api/requests.php', { action: 'approve', id });
    if (res.success) { toast(res.message); location.reload(); }
    else toast(res.message, 'error');
}

async function rejectRequest(id) {
    const reason = prompt('Reason for rejection (optional):') || '';
    const res = await api(BASE_URL + '/api/requests.php', { action: 'reject', id, admin_notes: reason });
    if (res.success) { toast(res.message, 'info'); location.reload(); }
    else toast(res.message, 'error');
}

async function returnEquipment(id) {
    if (!confirm('Confirm return of this equipment?')) return;
    const res = await api(BASE_URL + '/api/requests.php', { action: 'return', id });
    if (res.success) { toast(res.message); location.reload(); }
    else toast(res.message, 'error');
}

// ── DIRECT ISSUE (ADMIN) ──────────────────────────────────────
function showDirectIssue() {
    openModal('Issue Equipment Directly', `
        <div id="issueFormContainer"><p style="color:var(--text2)">Loading...</p></div>`);
    api(BASE_URL + '/api/requests.php', { action: 'get_issue_form_data' }).then(res => {
        if (!res.success) { document.getElementById('issueFormContainer').innerHTML = `<p class="form-error">${res.message}</p>`; return; }
        const playersOpts = res.players.map(p => `<option value="${p.id}">${p.name} (@${p.username})</option>`).join('');
        const equipOpts = res.equipment.map(e => `<option value="${e.id}">${e.emoji} ${e.name} (${e.available_units} avail)</option>`).join('');
        document.getElementById('issueFormContainer').innerHTML = `
            <form class="modal-form" onsubmit="submitDirectIssue(event)">
                <div class="form-group"><label>Player *</label><select name="user_id" required>${playersOpts}</select></div>
                <div class="form-group"><label>Equipment *</label><select name="equipment_id" required>${equipOpts}</select></div>
                <div class="form-row">
                    <div class="form-group"><label>Quantity *</label><input name="quantity" type="number" min="1" value="1" required></div>
                    <div class="form-group"><label>Due Date</label><input name="due_date" type="date" value="${dueDateDefault()}"></div>
                </div>
                <div class="form-group"><label>Notes</label><input name="notes" placeholder="Optional notes"></div>
                <div id="issueFormError"></div>
                <button type="submit" class="btn-primary btn-block">🔄 Issue Equipment</button>
            </form>`;
    });
}

async function submitDirectIssue(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    data.action = 'direct_issue';
    const res = await api(BASE_URL + '/api/requests.php', data);
    if (res.success) { toast(res.message); closeModal(); location.reload(); }
    else document.getElementById('issueFormError').innerHTML = `<div class="form-error">${res.message}</div>`;
}

// ── ADD PLAYER (ADMIN) ────────────────────────────────────────
function showAddPlayer() {
    openModal('Add Player', `
        <form class="modal-form" onsubmit="submitAddPlayer(event)">
            <div class="form-row">
                <div class="form-group"><label>Full Name *</label><input name="name" required placeholder="Player name"></div>
                <div class="form-group"><label>Username *</label><input name="username" required placeholder="username"></div>
            </div>
            <div class="form-group"><label>Email *</label><input name="email" type="email" required placeholder="email@example.com"></div>
            <div class="form-row">
                <div class="form-group"><label>Phone</label><input name="phone" placeholder="+91 9999999999"></div>
                <div class="form-group"><label>Password *</label><input name="password" type="password" required placeholder="Min 6 chars"></div>
            </div>
            <div id="playerFormError"></div>
            <button type="submit" class="btn-primary btn-block">👤 Add Player</button>
        </form>`);
}

async function submitAddPlayer(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    data.action = 'add_player';
    const res = await api(BASE_URL + '/api/players.php', data);
    if (res.success) { toast(res.message); closeModal(); location.reload(); }
    else document.getElementById('playerFormError').innerHTML = `<div class="form-error">${res.message}</div>`;
}

function deletePlayer(id) {
    confirmAction('Remove this player? All their request history will also be deleted.', async () => {
        const res = await api(BASE_URL + '/api/players.php', { action: 'delete', id });
        if (res.success) { toast(res.message); location.reload(); }
        else toast(res.message, 'error');
    });
}

// ── PLAYER: REQUEST EQUIPMENT ─────────────────────────────────
function showRequestEquipment(id, name, emoji, available) {
    openModal(`Request ${emoji} ${name}`, `
        <form class="modal-form" onsubmit="submitPlayerRequest(event,${id})">
            <p style="color:var(--text2);font-size:13px">${available} unit(s) currently available</p>
            <div class="form-group"><label>Quantity *</label><input name="quantity" type="number" min="1" max="${available}" value="1" required></div>
            <div class="form-group"><label>Purpose / Notes</label><textarea name="notes" placeholder="Why do you need this equipment?"></textarea></div>
            <div id="reqFormError"></div>
            <button type="submit" class="btn-primary btn-block">📋 Submit Request</button>
        </form>`);
}

async function submitPlayerRequest(e, equipmentId) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    data.action = 'player_request'; data.equipment_id = equipmentId;
    const res = await api(BASE_URL + '/api/requests.php', data);
    if (res.success) { toast(res.message); closeModal(); location.reload(); }
    else document.getElementById('reqFormError').innerHTML = `<div class="form-error">${res.message}</div>`;
}

// ── UTILITIES ─────────────────────────────────────────────────
function esc(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function dueDateDefault() {
    const d = new Date(); d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
}

// Auto-dismiss flash banners
setTimeout(() => { const f = document.getElementById('flashBanner'); if (f) f.style.opacity = '0'; }, 3500);
