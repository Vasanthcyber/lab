<?php
// index.php — Login Page
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $role = $_SESSION['user_role'];
    redirect(SITE_URL . ($role === 'admin' ? '/admin/dashboard.php' : '/player/dashboard.php'));
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role'] ?? 'player';

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND role = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$username, $role]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']       = $user['id'];
            $_SESSION['user_name']     = $user['name'];
            $_SESSION['user_role']     = $user['role'];
            $_SESSION['last_activity'] = time();
            $_SESSION['csrf_token']    = bin2hex(random_bytes(32));
            redirect(SITE_URL . ($user['role'] === 'admin' ? '/admin/dashboard.php' : '/player/dashboard.php'));
        } else {
            $error = 'Invalid credentials or account not found.';
        }
    }
}

// Live stats for hero panel
$db = getDB();
$totalItems   = $db->query("SELECT SUM(total_units) FROM equipment WHERE is_active=1")->fetchColumn() ?: 0;
$activeIssues = $db->query("SELECT COUNT(*) FROM equipment_requests WHERE status='approved'")->fetchColumn() ?: 0;
$totalPlayers = $db->query("SELECT COUNT(*) FROM users WHERE role='player' AND is_active=1")->fetchColumn() ?: 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — CricketVault EMS</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="login-page">
    <div class="login-wrapper">
        <!-- Hero -->
        <div class="login-hero">
            <div><span class="hero-badge">🏏 CricketVault v2.0</span></div>
            <div class="hero-title">EQUIPMENT<br><span>MANAGEMENT</span><br>SYSTEM</div>
            <div class="hero-stats">
                <div class="hero-stat"><div class="hero-stat-num"><?= $totalItems ?></div><div class="hero-stat-label">Total Items</div></div>
                <div class="hero-stat"><div class="hero-stat-num"><?= $activeIssues ?></div><div class="hero-stat-label">Active Loans</div></div>
                <div class="hero-stat"><div class="hero-stat-num"><?= $totalPlayers ?></div><div class="hero-stat-label">Players</div></div>
            </div>
        </div>

        <!-- Form -->
        <div class="login-form-panel">
            <div class="form-header">
                <h2>Welcome Back</h2>
                <p>Sign in to your account to continue</p>
            </div>

            <!-- Role Tabs -->
            <div class="role-tabs">
                <button type="button" class="role-tab <?= (($_POST['role']??'admin')==='admin')?'active':'' ?>" onclick="setRole('admin')">🔐 Admin</button>
                <button type="button" class="role-tab <?= (($_POST['role']??''))==='player'?'active':'' ?>" onclick="setRole('player')">🏏 Player</button>
            </div>

            <form method="POST" action="">
                <input type="hidden" name="role" id="roleInput" value="<?= htmlspecialchars($_POST['role']??'admin') ?>">
                <div class="modal-form">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" value="<?= htmlspecialchars($_POST['username']??'') ?>" placeholder="Enter username" required autofocus>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="Enter password" required>
                    </div>
                    <?php if ($error): ?>
                        <div class="form-error"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    <?php if (isset($_GET['timeout'])): ?>
                        <div class="form-error">Your session expired. Please log in again.</div>
                    <?php endif; ?>
                    <button type="submit" class="btn-primary btn-block">Sign In →</button>
                </div>
            </form>

            <div class="login-hints">
                Admin: <b>admin</b> / <b>password</b><br>
                Player: <b>rohit</b> / <b>password</b>
            </div>

            <div style="text-align:center;padding-top:4px;border-top:1px solid var(--border);margin-top:4px">
                <p style="font-size:13px;color:var(--text2)">
                    New player?
                    <a href="<?= SITE_URL ?>/register.php" style="color:var(--accent);font-weight:700;text-decoration:none">
                        Create an account →
                    </a>
                </p>
            </div>
        </div>
    </div>
</div>

<script>
function setRole(role) {
    document.getElementById('roleInput').value = role;
    document.querySelectorAll('.role-tab').forEach((t, i) => {
        t.classList.toggle('active', (i===0 && role==='admin') || (i===1 && role==='player'));
    });
}
</script>
</body>
</html>
