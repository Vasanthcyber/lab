<?php
// register.php — Player Self-Registration
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

// Already logged in? Redirect
if (isLoggedIn()) {
    redirect(SITE_URL . ($_SESSION['user_role'] === 'admin' ? '/admin/dashboard.php' : '/player/dashboard.php'));
}

$errors  = [];
$success = false;
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData['name']     = trim($_POST['name'] ?? '');
    $formData['username'] = trim($_POST['username'] ?? '');
    $formData['email']    = trim($_POST['email'] ?? '');
    $formData['phone']    = trim($_POST['phone'] ?? '');
    $password             = $_POST['password'] ?? '';
    $confirm              = $_POST['confirm_password'] ?? '';

    // Validate
    if (empty($formData['name']))
        $errors['name'] = 'Full name is required.';
    elseif (strlen($formData['name']) < 3)
        $errors['name'] = 'Name must be at least 3 characters.';

    if (empty($formData['username']))
        $errors['username'] = 'Username is required.';
    elseif (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $formData['username']))
        $errors['username'] = 'Username: 3–30 chars, letters/numbers/underscore only.';

    if (empty($formData['email']))
        $errors['email'] = 'Email address is required.';
    elseif (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL))
        $errors['email'] = 'Please enter a valid email address.';

    if (strlen($password) < 6)
        $errors['password'] = 'Password must be at least 6 characters.';

    if ($password !== $confirm)
        $errors['confirm_password'] = 'Passwords do not match.';

    // Check uniqueness
    if (empty($errors)) {
        $db  = getDB();
        $chk = $db->prepare("SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 2");
        $chk->execute([$formData['username'], $formData['email']]);
        $dupes = $chk->fetchAll();
        foreach ($dupes as $d) {
            if ($d['username'] === $formData['username'])
                $errors['username'] = 'This username is already taken.';
            if ($d['email'] === $formData['email'])
                $errors['email'] = 'This email is already registered.';
        }
    }

    // Insert
    if (empty($errors)) {
        $db   = getDB();
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $db->prepare(
            "INSERT INTO users (name, username, email, phone, password, role, is_active)
             VALUES (?, ?, ?, ?, ?, 'player', 1)"
        );
        $stmt->execute([
            $formData['name'],
            $formData['username'],
            $formData['email'],
            $formData['phone'],
            $hash
        ]);

        $success = true;
        $formData = []; // Clear form
    }
}

// Live stats
$db = getDB();
$totalItems   = $db->query("SELECT SUM(total_units) FROM equipment WHERE is_active=1")->fetchColumn() ?: 0;
$totalPlayers = $db->query("SELECT COUNT(*) FROM users WHERE role='player' AND is_active=1")->fetchColumn() ?: 0;
$equipTypes   = $db->query("SELECT COUNT(*) FROM equipment WHERE is_active=1")->fetchColumn() ?: 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register — CricketVault EMS</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
<style>
  /* ── REGISTER PAGE EXTRAS ── */
  .register-wrapper {
    display: flex;
    width: 960px;
    max-width: 96vw;
    min-height: 600px;
    border-radius: 20px;
    overflow: hidden;
    border: 1px solid var(--border);
    box-shadow: var(--shadow);
  }

  .register-hero {
    width: 340px;
    flex-shrink: 0;
    background: linear-gradient(160deg, #0d1117 0%, #0f1820 60%, #0d1117 100%);
    padding: 48px 36px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    position: relative;
    overflow: hidden;
  }
  .register-hero::before {
    content: '';
    position: absolute; inset: 0;
    background:
      radial-gradient(ellipse at 10% 90%, rgba(200,240,78,0.1) 0%, transparent 55%),
      radial-gradient(ellipse at 90% 10%, rgba(79,163,255,0.06) 0%, transparent 55%);
  }
  .register-hero::after {
    content: '🏏';
    position: absolute;
    font-size: 160px;
    bottom: -20px;
    right: -30px;
    opacity: 0.06;
    transform: rotate(-15deg);
    pointer-events: none;
  }

  .hero-feature-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
    position: relative;
  }
  .hero-feature {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 13px;
    color: var(--text2);
  }
  .hero-feature-icon {
    width: 30px; height: 30px;
    border-radius: 8px;
    background: rgba(200,240,78,0.08);
    border: 1px solid rgba(200,240,78,0.15);
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; flex-shrink: 0;
  }

  .register-form-panel {
    flex: 1;
    background: var(--panel);
    padding: 44px 44px;
    display: flex;
    flex-direction: column;
    gap: 0;
    overflow-y: auto;
  }

  .register-form-panel .form-header {
    margin-bottom: 28px;
  }
  .register-form-panel .form-header h2 {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 38px;
    letter-spacing: 0.5px;
  }
  .register-form-panel .form-header p {
    font-size: 13px;
    color: var(--text2);
    margin-top: 5px;
  }

  .input-wrapper { position: relative; }
  .input-wrapper input {
    padding-left: 42px !important;
  }
  .input-icon {
    position: absolute;
    left: 14px; top: 50%;
    transform: translateY(-50%);
    font-size: 15px;
    pointer-events: none;
  }

  .field-error {
    font-size: 11px;
    color: var(--red);
    margin-top: 4px;
    display: flex;
    align-items: center;
    gap: 4px;
  }
  .field-error::before { content: '⚠'; }

  .input-valid {
    border-color: var(--green) !important;
  }
  .input-invalid {
    border-color: var(--red) !important;
    box-shadow: 0 0 0 3px rgba(255,71,87,0.08) !important;
  }

  .password-strength {
    margin-top: 6px;
    display: flex;
    flex-direction: column;
    gap: 5px;
  }
  .strength-bar {
    height: 4px;
    background: var(--border);
    border-radius: 2px;
    overflow: hidden;
  }
  .strength-fill {
    height: 100%;
    border-radius: 2px;
    transition: width 0.3s, background 0.3s;
    width: 0%;
  }
  .strength-label {
    font-size: 11px;
    color: var(--text3);
  }

  .register-footer {
    margin-top: 22px;
    text-align: center;
    font-size: 13px;
    color: var(--text2);
  }
  .register-footer a {
    color: var(--accent);
    font-weight: 600;
  }
  .register-footer a:hover {
    text-decoration: underline;
  }

  .success-panel {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    gap: 20px;
    padding: 40px 20px;
    flex: 1;
  }
  .success-icon {
    width: 80px; height: 80px;
    border-radius: 50%;
    background: rgba(74,222,128,0.1);
    border: 2px solid var(--green);
    display: flex; align-items: center; justify-content: center;
    font-size: 36px;
    animation: popIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
  }
  @keyframes popIn {
    from { transform: scale(0); opacity: 0; }
    to   { transform: scale(1); opacity: 1; }
  }
  .success-panel h3 {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 32px;
  }
  .success-panel p {
    font-size: 14px;
    color: var(--text2);
    max-width: 320px;
    line-height: 1.6;
  }

  .divider {
    display: flex; align-items: center; gap: 12px;
    margin: 4px 0;
    color: var(--text3);
    font-size: 12px;
  }
  .divider::before, .divider::after {
    content: ''; flex: 1;
    height: 1px; background: var(--border);
  }

  .terms-text {
    font-size: 11px;
    color: var(--text3);
    line-height: 1.6;
    text-align: center;
    margin-top: 4px;
  }
</style>
</head>
<body>

<div class="login-page">
  <div class="register-wrapper">

    <!-- ── HERO PANEL ── -->
    <div class="register-hero">
      <div style="position:relative">
        <span class="hero-badge">🏏 CricketVault</span>
        <div class="hero-title" style="margin-top:24px;font-size:52px">
          JOIN THE<br><span>SQUAD</span>
        </div>
        <p style="font-size:13px;color:var(--text2);margin-top:12px;line-height:1.7;position:relative">
          Create your player account to request equipment, track your loans, and manage your gear.
        </p>
      </div>

      <div class="hero-feature-list" style="position:relative">
        <div class="hero-feature">
          <div class="hero-feature-icon">📋</div>
          <span>Request any equipment in seconds</span>
        </div>
        <div class="hero-feature">
          <div class="hero-feature-icon">🔄</div>
          <span>Track your active loans & due dates</span>
        </div>
        <div class="hero-feature">
          <div class="hero-feature-icon">📖</div>
          <span>Full personal usage history</span>
        </div>
        <div class="hero-feature">
          <div class="hero-feature-icon">✅</div>
          <span>Instant stock availability view</span>
        </div>
      </div>

      <div class="hero-stats" style="position:relative">
        <div class="hero-stat">
          <div class="hero-stat-num"><?= $totalItems ?></div>
          <div class="hero-stat-label">Total Items</div>
        </div>
        <div class="hero-stat">
          <div class="hero-stat-num"><?= $equipTypes ?></div>
          <div class="hero-stat-label">Equipment Types</div>
        </div>
        <div class="hero-stat">
          <div class="hero-stat-num"><?= $totalPlayers ?></div>
          <div class="hero-stat-label">Players</div>
        </div>
      </div>
    </div>

    <!-- ── FORM PANEL ── -->
    <div class="register-form-panel">

      <?php if ($success): ?>
      <!-- SUCCESS STATE -->
      <div class="success-panel">
        <div class="success-icon">✅</div>
        <h3>Account Created!</h3>
        <p>Your player account has been successfully registered. You can now sign in and start requesting equipment.</p>
        <a href="<?= SITE_URL ?>/index.php?role=player" class="btn-primary" style="margin-top:8px">
          🏏 Go to Login →
        </a>
        <p style="font-size:12px;color:var(--text3);margin-top:8px">
          Use your username and password to sign in as a <b>Player</b>
        </p>
      </div>

      <?php else: ?>
      <!-- REGISTER FORM -->
      <div class="form-header">
        <h2>Create Account</h2>
        <p>Register as a player to access equipment</p>
      </div>

      <form method="POST" action="" id="registerForm" novalidate>
        <div style="display:flex;flex-direction:column;gap:16px">

          <!-- Name + Username -->
          <div class="form-row">
            <div class="form-group">
              <label>Full Name *</label>
              <div class="input-wrapper">
                <span class="input-icon">👤</span>
                <input
                  type="text" name="name"
                  value="<?= htmlspecialchars($formData['name'] ?? '') ?>"
                  placeholder="e.g. Rohit Sharma"
                  class="<?= isset($errors['name']) ? 'input-invalid' : (isset($formData['name']) && !empty($formData['name']) ? 'input-valid' : '') ?>"
                  required>
              </div>
              <?php if (isset($errors['name'])): ?>
                <div class="field-error"><?= $errors['name'] ?></div>
              <?php endif; ?>
            </div>

            <div class="form-group">
              <label>Username *</label>
              <div class="input-wrapper">
                <span class="input-icon">@</span>
                <input
                  type="text" name="username"
                  value="<?= htmlspecialchars($formData['username'] ?? '') ?>"
                  placeholder="e.g. rohit_sharma"
                  class="<?= isset($errors['username']) ? 'input-invalid' : (isset($formData['username']) && !empty($formData['username']) ? 'input-valid' : '') ?>"
                  oninput="checkUsername(this)"
                  required>
              </div>
              <?php if (isset($errors['username'])): ?>
                <div class="field-error"><?= $errors['username'] ?></div>
              <?php else: ?>
                <div style="font-size:11px;color:var(--text3);margin-top:4px">Letters, numbers, underscore — 3 to 30 chars</div>
              <?php endif; ?>
            </div>
          </div>

          <!-- Email -->
          <div class="form-group">
            <label>Email Address *</label>
            <div class="input-wrapper">
              <span class="input-icon">✉️</span>
              <input
                type="email" name="email"
                value="<?= htmlspecialchars($formData['email'] ?? '') ?>"
                placeholder="you@example.com"
                class="<?= isset($errors['email']) ? 'input-invalid' : (isset($formData['email']) && !empty($formData['email']) ? 'input-valid' : '') ?>"
                required>
            </div>
            <?php if (isset($errors['email'])): ?>
              <div class="field-error"><?= $errors['email'] ?></div>
            <?php endif; ?>
          </div>

          <!-- Phone -->
          <div class="form-group">
            <label>Phone Number <span style="color:var(--text3);font-weight:400">(optional)</span></label>
            <div class="input-wrapper">
              <span class="input-icon">📱</span>
              <input
                type="tel" name="phone"
                value="<?= htmlspecialchars($formData['phone'] ?? '') ?>"
                placeholder="+91 98765 43210">
            </div>
          </div>

          <div class="divider">Password Setup</div>

          <!-- Password + Confirm -->
          <div class="form-row">
            <div class="form-group">
              <label>Password *</label>
              <div class="input-wrapper">
                <span class="input-icon">🔑</span>
                <input
                  type="password" name="password" id="passwordInput"
                  placeholder="Min 6 characters"
                  class="<?= isset($errors['password']) ? 'input-invalid' : '' ?>"
                  oninput="updateStrength(this.value)"
                  required>
              </div>
              <?php if (isset($errors['password'])): ?>
                <div class="field-error"><?= $errors['password'] ?></div>
              <?php else: ?>
                <div class="password-strength">
                  <div class="strength-bar"><div class="strength-fill" id="strengthBar"></div></div>
                  <div class="strength-label" id="strengthLabel">Enter a password</div>
                </div>
              <?php endif; ?>
            </div>

            <div class="form-group">
              <label>Confirm Password *</label>
              <div class="input-wrapper">
                <span class="input-icon">🔒</span>
                <input
                  type="password" name="confirm_password" id="confirmInput"
                  placeholder="Repeat your password"
                  class="<?= isset($errors['confirm_password']) ? 'input-invalid' : '' ?>"
                  oninput="checkMatch()"
                  required>
              </div>
              <?php if (isset($errors['confirm_password'])): ?>
                <div class="field-error"><?= $errors['confirm_password'] ?></div>
              <?php else: ?>
                <div class="field-error" id="matchError" style="display:none">Passwords do not match</div>
              <?php endif; ?>
            </div>
          </div>

          <!-- Submit -->
          <button type="submit" class="btn-primary btn-block" style="margin-top:4px" id="submitBtn">
            🏏 Create My Account
          </button>

          <p class="terms-text">
            By registering, you agree to use equipment responsibly and return it on time.<br>
            Your account is subject to admin approval for equipment requests.
          </p>
        </div>
      </form>

      <div class="register-footer">
        Already have an account?
        <a href="<?= SITE_URL ?>/index.php">Sign in here →</a>
      </div>
      <?php endif; ?>

    </div>
  </div>
</div>

<script>
// ── PASSWORD STRENGTH ──────────────────────────────────────────
function updateStrength(pw) {
    const bar   = document.getElementById('strengthBar');
    const label = document.getElementById('strengthLabel');
    if (!bar) return;

    let score = 0;
    if (pw.length >= 6)  score++;
    if (pw.length >= 10) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;

    const levels = [
        { pct: 0,   color: 'var(--border)', label: 'Enter a password' },
        { pct: 20,  color: 'var(--red)',    label: 'Very weak' },
        { pct: 40,  color: 'var(--red)',    label: 'Weak' },
        { pct: 60,  color: 'var(--orange)', label: 'Fair' },
        { pct: 80,  color: 'var(--accent)', label: 'Strong' },
        { pct: 100, color: 'var(--green)',  label: '💪 Very strong' },
    ];

    const lvl = levels[score] || levels[0];
    bar.style.width     = lvl.pct + '%';
    bar.style.background = lvl.color;
    label.textContent   = lvl.label;
    label.style.color   = lvl.color;
}

// ── CONFIRM MATCH ──────────────────────────────────────────────
function checkMatch() {
    const pw  = document.getElementById('passwordInput')?.value;
    const cfm = document.getElementById('confirmInput')?.value;
    const err = document.getElementById('matchError');
    if (!err || !cfm) return;
    err.style.display = (cfm && pw !== cfm) ? 'flex' : 'none';
    document.getElementById('confirmInput').className =
        cfm ? (pw === cfm ? 'input-valid' : 'input-invalid') : '';
}

// ── USERNAME HINT ──────────────────────────────────────────────
function checkUsername(input) {
    const val = input.value;
    const ok  = /^[a-zA-Z0-9_]{3,30}$/.test(val);
    input.className = val.length >= 3 ? (ok ? 'input-valid' : 'input-invalid') : '';
}

// ── FORM SUBMIT GUARD ─────────────────────────────────────────
document.getElementById('registerForm')?.addEventListener('submit', function(e) {
    const pw  = document.getElementById('passwordInput')?.value;
    const cfm = document.getElementById('confirmInput')?.value;
    if (pw !== cfm) {
        e.preventDefault();
        document.getElementById('matchError').style.display = 'flex';
        document.getElementById('confirmInput').focus();
        return;
    }
    const btn = document.getElementById('submitBtn');
    btn.disabled = true;
    btn.textContent = 'Creating Account…';
});
</script>
</body>
</html>
