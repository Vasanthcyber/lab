# CricketVault — Equipment Management System
### PHP + MySQL + HTML/CSS/JavaScript

---

## 📁 Project Structure

```
cricket_ems/
├── index.php                  # Login page
├── logout.php                 # Logout
├── database.sql               # Full DB schema + seed data
│
├── config/
│   └── db.php                 # DB credentials & PDO connection
│
├── includes/
│   ├── auth.php               # Session, CSRF, helper functions
│   ├── header.php             # Shared HTML head + sidebar
│   └── footer.php             # Shared modal + scripts
│
├── admin/
│   ├── dashboard.php          # Admin dashboard with stats
│   ├── equipment.php          # Add/Edit/Delete equipment
│   ├── inventory.php          # Stock levels + change log
│   ├── requests.php           # Approve/Reject requests
│   ├── issues.php             # Issued & returned items
│   ├── players.php            # Player management
│   └── reports.php            # Analytics & reports
│
├── player/
│   ├── dashboard.php          # Player home
│   ├── browse.php             # Browse available equipment
│   ├── requests.php           # My requests
│   └── history.php            # Usage history
│
├── api/
│   ├── equipment.php          # Equipment CRUD API
│   ├── requests.php           # Request management API
│   └── players.php            # Player management API
│
└── assets/
    ├── css/style.css          # Full stylesheet
    └── js/app.js              # Frontend JS (modal, toast, API calls)
```

---

## ⚙️ Installation & Setup

### Requirements
- PHP 8.0 or higher
- MySQL 5.7 / MariaDB 10.4 or higher
- Apache/Nginx with `mod_rewrite` (or XAMPP/WAMP/MAMP)

---

### Step 1 — Copy Files
Place the entire `cricket_ems/` folder inside your web server root:
- **XAMPP:** `C:\xampp\htdocs\cricket_ems\`
- **MAMP:** `/Applications/MAMP/htdocs/cricket_ems/`
- **Linux:** `/var/www/html/cricket_ems/`

---

### Step 2 — Create Database
1. Open **phpMyAdmin** (or MySQL CLI)
2. Run the SQL file:
```sql
SOURCE /path/to/cricket_ems/database.sql;
```
Or paste the contents of `database.sql` into phpMyAdmin's SQL tab.

---

### Step 3 — Configure Database
Edit `config/db.php` and update:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Your MySQL username
define('DB_PASS', '');            // Your MySQL password
define('DB_NAME', 'cricket_ems');
define('SITE_URL', 'http://localhost/cricket_ems');
```

---

### Step 4 — Access the App
Open your browser and go to:
```
http://localhost/cricket_ems/
```

---

## 🔐 Default Login Credentials

| Role   | Username | Password   |
|--------|----------|-----------|
| Admin  | admin    | password  |
| Player | rohit    | password  |
| Player | virat    | password  |
| Player | dhoni    | password  |
| Player | bumrah   | password  |

> ⚠️ Change passwords after first login in production!

---

## ✅ Features Implemented

### Admin Module
- [x] Admin login with session management
- [x] Add / Edit / Delete equipment
- [x] Check stock with progress bars and low-stock alerts
- [x] Approve or reject player requests (with admin notes)
- [x] View issued, returned, and damaged items
- [x] Direct issue equipment to players
- [x] Add and remove players
- [x] Reports & analytics

### Player Module
- [x] Player login
- [x] Browse available equipment with category filter
- [x] Request equipment with quantity & notes
- [x] View own request status (pending/approved/rejected/returned)
- [x] Usage history with duration tracking

### Equipment Management
- [x] Store equipment details (name, category, emoji, description)
- [x] Update stock via restock modal
- [x] Mark items as damaged (with reason logging)
- [x] Mark items as repaired (returns to available stock)
- [x] Soft delete (preserves history)

### Issue & Return Module
- [x] Issue equipment to users (via approval or direct issue)
- [x] Record return of items
- [x] Stock updates automatically on all actions
- [x] Overdue items highlighted in red

### Inventory Module
- [x] Check availability with visual progress bars
- [x] Track low stock with configurable minimum levels and alerts
- [x] Monitor total / available / issued / damaged counts
- [x] Full stock change log with timestamps

### Security
- [x] Password hashing (bcrypt via `password_hash`)
- [x] CSRF token validation on all API calls
- [x] PDO prepared statements (SQL injection prevention)
- [x] Session timeout (1 hour)
- [x] Role-based access control (admin vs player)
- [x] Input sanitization via `htmlspecialchars`

---

## 🗄️ Database Schema

| Table | Purpose |
|-------|---------|
| `users` | Admin and player accounts |
| `equipment` | Equipment catalog with stock counts |
| `equipment_requests` | All requests, issues, and returns |
| `damage_log` | Audit log for damage/repair events |
| `stock_log` | Complete stock change history |

---

## 🔧 Customization

- **Session timeout:** Change `SESSION_TIMEOUT` in `config/db.php`
- **Site URL:** Update `SITE_URL` in `config/db.php`
- **Due date default:** Change `+14 days` in `api/requests.php`
- **Min stock level:** Set per equipment item in the edit form
