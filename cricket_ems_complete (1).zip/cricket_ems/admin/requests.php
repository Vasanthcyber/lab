<?php
define('PAGE_TITLE', 'Requests');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('admin');

$db = getDB();

$statusFilter = $_GET['status'] ?? 'all';
$where = $statusFilter !== 'all' ? "WHERE r.status = " . $db->quote($statusFilter) : "";

$requests = $db->query("
    SELECT r.*, u.name as player_name, u.username,
           e.name as equip_name, e.emoji,
           a.name as admin_name
    FROM equipment_requests r
    JOIN users u ON r.user_id = u.id
    JOIN equipment e ON r.equipment_id = e.id
    LEFT JOIN users a ON r.admin_id = a.id
    $where
    ORDER BY r.created_at DESC
")->fetchAll();

$counts = $db->query("SELECT status, COUNT(*) as cnt FROM equipment_requests GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Requests</h2><p>Approve or reject equipment requests from players</p></div>
</div>

<div class="stat-grid">
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">⏳</span><span class="badge badge-orange">Pending</span></div><div class="stat-num"><?= $counts['pending']??0 ?></div><div class="stat-label">Awaiting Review</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">✅</span><span class="badge badge-blue">Approved</span></div><div class="stat-num"><?= $counts['approved']??0 ?></div><div class="stat-label">Active Issues</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">↩️</span><span class="badge badge-green">Returned</span></div><div class="stat-num"><?= $counts['returned']??0 ?></div><div class="stat-label">Returned Items</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">❌</span><span class="badge badge-red">Rejected</span></div><div class="stat-num"><?= $counts['rejected']??0 ?></div><div class="stat-label">Rejected</div></div>
</div>

<!-- Filter Tabs -->
<div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">
    <?php foreach (['all','pending','approved','returned','rejected'] as $s): ?>
    <a href="?status=<?= $s ?>" class="btn-secondary btn-sm <?= $statusFilter===$s?'':''; ?>" style="<?= $statusFilter===$s?'background:var(--accent);color:var(--bg);border-color:var(--accent)':'' ?>"><?= ucfirst($s) ?></a>
    <?php endforeach; ?>
</div>

<div class="table-card">
    <div class="table-header">
        <h3>All Requests (<?= count($requests) ?>)</h3>
        <input class="search-input" placeholder="🔍 Search..." oninput="filterTable(this,'reqTbody')">
    </div>
    <table>
        <thead><tr><th>Player</th><th>Equipment</th><th>Qty</th><th>Request Date</th><th>Due Date</th><th>Status</th><th>Notes</th><th>Admin Notes</th><th>Actions</th></tr></thead>
        <tbody id="reqTbody">
        <?php if ($requests): foreach ($requests as $r):
            $pills = ['approved'=>'pill-blue','pending'=>'pill-orange','returned'=>'pill-green','rejected'=>'pill-red','cancelled'=>'pill-grey'];
            $overdue = $r['status']==='approved' && $r['due_date'] && strtotime($r['due_date']) < time();
        ?>
            <tr>
                <td><b><?= htmlspecialchars($r['player_name']) ?></b><div class="td-sub">@<?= $r['username'] ?></div></td>
                <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                <td><?= $r['quantity'] ?></td>
                <td><?= date('d M Y', strtotime($r['request_date'])) ?></td>
                <td class="<?= $overdue?'overdue':'' ?>"><?= $r['due_date'] ? date('d M Y', strtotime($r['due_date'])) : '—' ?><?= $overdue?' ⚠️':'' ?></td>
                <td><span class="pill <?= $pills[$r['status']] ?>"><?= $r['status'] ?></span></td>
                <td style="font-size:12px;color:var(--text2);max-width:120px"><?= htmlspecialchars($r['notes'] ?: '—') ?></td>
                <td style="font-size:12px;color:var(--text2);max-width:120px"><?= htmlspecialchars($r['admin_notes'] ?: '—') ?></td>
                <td>
                    <div class="action-btns">
                        <?php if ($r['status']==='pending'): ?>
                            <button class="btn-success btn-sm" onclick="approveRequest(<?= $r['id'] ?>)">✅ Approve</button>
                            <button class="btn-danger btn-sm" onclick="rejectRequest(<?= $r['id'] ?>)">❌ Reject</button>
                        <?php elseif ($r['status']==='approved'): ?>
                            <button class="btn-warning btn-sm" onclick="returnEquipment(<?= $r['id'] ?>)">↩ Return</button>
                        <?php else: ?>
                            <span style="font-size:11px;color:var(--text3)">No actions</span>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="9"><div class="empty-state"><div class="empty-icon">📋</div><p>No requests found</p></div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
