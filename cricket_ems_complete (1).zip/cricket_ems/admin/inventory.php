<?php
define('PAGE_TITLE', 'Inventory');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('admin');

$db = getDB();
$equipment = $db->query("SELECT * FROM equipment WHERE is_active=1 ORDER BY name")->fetchAll();

$totalUnits   = array_sum(array_column($equipment, 'total_units'));
$availUnits   = array_sum(array_column($equipment, 'available_units'));
$damagedUnits = array_sum(array_column($equipment, 'damaged_units'));
$issuedUnits  = $totalUnits - $availUnits - $damagedUnits;
$lowStock     = array_filter($equipment, fn($e) => $e['available_units'] <= $e['min_stock_level']);

// Recent stock log
$stockLog = $db->query("
    SELECT sl.*, e.name as equip_name, e.emoji, u.name as logged_by_name
    FROM stock_log sl
    JOIN equipment e ON sl.equipment_id = e.id
    LEFT JOIN users u ON sl.logged_by = u.id
    ORDER BY sl.logged_at DESC LIMIT 20
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Inventory</h2><p>Complete stock visibility and monitoring</p></div>
    <button class="btn-primary" onclick="showRestock(null,'')">+ Restock Item</button>
</div>

<div class="stat-grid">
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">📦</span><span class="badge badge-blue">Total</span></div><div class="stat-num"><?= $totalUnits ?></div><div class="stat-label">Total Units All Items</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">✅</span><span class="badge badge-green">Available</span></div><div class="stat-num"><?= $availUnits ?></div><div class="stat-label">Ready to Issue</div>
        <div class="progress-bar"><div class="progress-fill" style="width:<?= $totalUnits>0?round($availUnits/$totalUnits*100):0 ?>%;background:var(--green)"></div></div>
    </div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">🔄</span><span class="badge badge-orange">Issued</span></div><div class="stat-num"><?= $issuedUnits ?></div><div class="stat-label">With Players</div>
        <div class="progress-bar"><div class="progress-fill" style="width:<?= $totalUnits>0?round($issuedUnits/$totalUnits*100):0 ?>%;background:var(--orange)"></div></div>
    </div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">🔴</span><span class="badge badge-red">Damaged</span></div><div class="stat-num"><?= $damagedUnits ?></div><div class="stat-label">Damaged / Repair Queue</div>
        <div class="progress-bar"><div class="progress-fill" style="width:<?= $totalUnits>0?round($damagedUnits/$totalUnits*100):0 ?>%;background:var(--red)"></div></div>
    </div>
</div>

<?php if ($lowStock): ?>
<div class="alert-banner">
    ⚠️ <b>Low Stock Alert (<?= count($lowStock) ?> items):</b>
    <?php foreach ($lowStock as $ls): ?>
        <span class="pill pill-red"><?= $ls['emoji'] ?> <?= htmlspecialchars($ls['name']) ?> (<?= $ls['available_units'] ?>/<?= $ls['min_stock_level'] ?>)</span>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="table-card" style="margin-bottom:24px">
    <div class="table-header"><h3>📋 Stock Details</h3><input class="search-input" placeholder="🔍 Search..." oninput="filterTable(this,'invTbody')"></div>
    <table>
        <thead><tr><th>Equipment</th><th>Category</th><th>Total</th><th>Available</th><th>Issued</th><th>Damaged</th><th>Min Stock</th><th>Availability</th><th>Status</th><th>Action</th></tr></thead>
        <tbody id="invTbody">
        <?php foreach ($equipment as $e):
            $issued = $e['total_units'] - $e['available_units'] - $e['damaged_units'];
            $pct = $e['total_units'] > 0 ? round($e['available_units'] / $e['total_units'] * 100) : 0;
            $barColor = $e['available_units'] <= $e['min_stock_level'] ? 'var(--red)' : ($e['available_units'] <= $e['min_stock_level']*2 ? 'var(--orange)' : 'var(--green)');
            $pillClass = $e['available_units'] <= $e['min_stock_level'] ? 'pill-red' : ($e['available_units'] <= $e['min_stock_level']*2 ? 'pill-orange' : 'pill-green');
            $label = $e['available_units'] <= $e['min_stock_level'] ? '⚠️ Low Stock' : ($e['available_units'] <= $e['min_stock_level']*2 ? 'Moderate' : 'Good');
        ?>
        <tr>
            <td><b><?= $e['emoji'] ?> <?= htmlspecialchars($e['name']) ?></b></td>
            <td><?= $e['category'] ?></td>
            <td class="td-mono"><?= $e['total_units'] ?></td>
            <td class="td-mono" style="color:var(--green)"><?= $e['available_units'] ?></td>
            <td class="td-mono" style="color:var(--orange)"><?= $issued ?></td>
            <td class="td-mono" style="color:var(--red)"><?= $e['damaged_units'] ?></td>
            <td class="td-mono"><?= $e['min_stock_level'] ?></td>
            <td style="width:140px">
                <div style="display:flex;align-items:center;gap:8px">
                    <div class="progress-bar" style="flex:1"><div class="progress-fill" style="width:<?= $pct ?>%;background:<?= $barColor ?>"></div></div>
                    <span class="td-mono"><?= $pct ?>%</span>
                </div>
            </td>
            <td><span class="pill <?= $pillClass ?>"><?= $label ?></span></td>
            <td><button class="btn-secondary btn-sm" onclick="showRestock(<?= $e['id'] ?>,'<?= addslashes($e['name']) ?>')">📦 Restock</button></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Stock Log -->
<div class="table-card">
    <div class="table-header"><h3>📜 Stock Change Log</h3></div>
    <table>
        <thead><tr><th>Equipment</th><th>Type</th><th>Change</th><th>New Available</th><th>By</th><th>Date</th><th>Notes</th></tr></thead>
        <tbody>
        <?php if ($stockLog): foreach ($stockLog as $log):
            $typeColors = ['restock'=>'pill-green','issue'=>'pill-orange','return'=>'pill-blue','damage'=>'pill-red','repair'=>'pill-green'];
        ?>
            <tr>
                <td><?= $log['emoji'] ?> <?= htmlspecialchars($log['equip_name']) ?></td>
                <td><span class="pill <?= $typeColors[$log['change_type']] ?? 'pill-grey' ?>"><?= $log['change_type'] ?></span></td>
                <td class="td-mono" style="color:<?= $log['quantity_change']>=0?'var(--green)':'var(--red)' ?>"><?= ($log['quantity_change']>=0?'+':'') . $log['quantity_change'] ?></td>
                <td class="td-mono"><?= $log['new_available'] ?></td>
                <td><?= htmlspecialchars($log['logged_by_name'] ?? 'System') ?></td>
                <td style="font-size:12px;color:var(--text2)"><?= date('d M Y H:i', strtotime($log['logged_at'])) ?></td>
                <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($log['notes'] ?: '—') ?></td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="7"><div class="empty-state"><p>No stock changes yet</p></div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
// Override generic restock to always show all equipment when called from inventory
function showRestock(id, name) {
    fetch(BASE_URL + '/api/equipment.php', {
        method:'POST', body: (() => { const f = new FormData(); f.append('action','list_for_restock');
        f.append('csrf_token', document.querySelector('meta[name="csrf"]').content); return f; })()
    }).then(r=>r.json()).then(res => {
        const opts = res.items.map(e => `<option value="${e.id}" ${e.id==id?'selected':''}>${e.emoji} ${e.name} (avail: ${e.available_units})</option>`).join('');
        openModal('Restock Equipment', `
            <div class="modal-form">
                <div class="form-group"><label>Equipment</label><select id="rstockEq">${opts}</select></div>
                <div class="form-group"><label>Units to Add</label><input id="rstockQty" type="number" min="1" value="10"></div>
                <div class="form-group"><label>Notes (optional)</label><input id="rstockNotes" placeholder="e.g. New batch purchased"></div>
                <div id="rstockError"></div>
                <button class="btn-primary btn-block" onclick="doRestockFromSelect()">📦 Add Stock</button>
            </div>`);
    });
}
async function doRestockFromSelect() {
    const id = document.getElementById('rstockEq').value;
    const qty = document.getElementById('rstockQty').value;
    const notes = document.getElementById('rstockNotes').value;
    const csrf = document.querySelector('meta[name="csrf"]').content;
    const form = new FormData(); form.append('csrf_token',csrf); form.append('action','restock');
    form.append('id',id); form.append('quantity',qty); form.append('notes',notes);
    const res = await (await fetch(BASE_URL+'/api/equipment.php',{method:'POST',body:form})).json();
    if (res.success) { toast(res.message); closeModal(); location.reload(); }
    else document.getElementById('rstockError').innerHTML = `<div class="form-error">${res.message}</div>`;
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
