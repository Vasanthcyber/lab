<?php
define('PAGE_TITLE', 'Equipment');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('admin');

$db = getDB();
$equipment = $db->query("SELECT * FROM equipment WHERE is_active=1 ORDER BY category, name")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Equipment</h2><p>Manage all cricket equipment in the inventory</p></div>
    <button class="btn-primary" onclick="showAddEquipment()">+ Add Equipment</button>
</div>

<div class="table-card">
    <div class="table-header">
        <h3>All Equipment (<?= count($equipment) ?>)</h3>
        <input class="search-input" placeholder="🔍 Search equipment..." oninput="filterTable(this,'equipTbody')">
    </div>
    <table>
        <thead>
            <tr>
                <th>Item</th><th>Category</th><th>Total</th><th>Available</th>
                <th>Issued</th><th>Damaged</th><th>Min Stock</th><th>Status</th><th>Actions</th>
            </tr>
        </thead>
        <tbody id="equipTbody">
        <?php foreach ($equipment as $e):
            $issued = $e['total_units'] - $e['available_units'] - $e['damaged_units'];
            $pillClass = $e['available_units'] <= $e['min_stock_level'] ? 'pill-red' : ($e['available_units'] <= $e['min_stock_level']*2 ? 'pill-orange' : 'pill-green');
            $label = $e['available_units'] <= $e['min_stock_level'] ? 'Low Stock' : ($e['available_units'] <= $e['min_stock_level']*2 ? 'Moderate' : 'In Stock');
        ?>
            <tr>
                <td>
                    <div class="td-name"><?= $e['emoji'] ?> <?= htmlspecialchars($e['name']) ?></div>
                    <div class="td-sub"><?= htmlspecialchars($e['description'] ?: '—') ?></div>
                </td>
                <td><span class="pill pill-blue"><?= $e['category'] ?></span></td>
                <td class="td-mono"><?= $e['total_units'] ?></td>
                <td class="td-mono" style="color:var(--green)"><?= $e['available_units'] ?></td>
                <td class="td-mono" style="color:var(--orange)"><?= $issued ?></td>
                <td class="td-mono" style="color:var(--red)"><?= $e['damaged_units'] ?></td>
                <td class="td-mono"><?= $e['min_stock_level'] ?></td>
                <td><span class="pill <?= $pillClass ?>"><?= $label ?></span></td>
                <td>
                    <div class="action-btns">
                        <button class="btn-secondary btn-sm" onclick="showEditEquipment(<?= $e['id'] ?>)">✏️ Edit</button>
                        <button class="btn-warning btn-sm" onclick="showMarkDamaged(<?= $e['id'] ?>, '<?= addslashes($e['name']) ?>', <?= $e['available_units'] ?>)">🔴 Damage</button>
                        <button class="btn-success btn-sm" onclick="showMarkRepaired(<?= $e['id'] ?>, '<?= addslashes($e['name']) ?>', <?= $e['damaged_units'] ?>)" <?= $e['damaged_units']<=0 ? 'disabled style="opacity:0.4"' : '' ?>>🟢 Repair</button>
                        <button class="btn-secondary btn-sm" onclick="showRestock(<?= $e['id'] ?>, '<?= addslashes($e['name']) ?>')">📦 Restock</button>
                        <button class="btn-danger btn-sm" onclick="deleteEquipment(<?= $e['id'] ?>)">🗑️ Delete</button>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($equipment)): ?>
            <tr><td colspan="9"><div class="empty-state"><div class="empty-icon">🏏</div><p>No equipment found. Add your first item!</p></div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
