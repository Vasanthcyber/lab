<?php
define('PAGE_TITLE', 'Players');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('admin');

$db = getDB();
$players = $db->query("
    SELECT u.*,
        COUNT(r.id) as total_requests,
        SUM(r.status='approved') as active_loans
    FROM users u
    LEFT JOIN equipment_requests r ON r.user_id = u.id
    WHERE u.role='player'
    GROUP BY u.id ORDER BY u.created_at DESC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Players</h2><p>Manage registered players</p></div>
    <button class="btn-primary" onclick="showAddPlayer()">+ Add Player</button>
</div>

<div class="table-card">
    <div class="table-header">
        <h3>All Players (<?= count($players) ?>)</h3>
        <input class="search-input" placeholder="🔍 Search..." oninput="filterTable(this,'playerTbody')">
    </div>
    <table>
        <thead><tr><th>Player</th><th>Username</th><th>Email</th><th>Phone</th><th>Joined</th><th>Active Loans</th><th>Total Requests</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="playerTbody">
        <?php if ($players): foreach ($players as $p): ?>
            <tr>
                <td>
                    <div style="display:flex;align-items:center;gap:10px">
                        <div class="user-avatar" style="width:32px;height:32px;font-size:13px;border-radius:8px"><?= strtoupper(substr($p['name'],0,1)) ?></div>
                        <b><?= htmlspecialchars($p['name']) ?></b>
                    </div>
                </td>
                <td class="td-mono">@<?= htmlspecialchars($p['username']) ?></td>
                <td style="color:var(--text2)"><?= htmlspecialchars($p['email']) ?></td>
                <td style="color:var(--text2)"><?= htmlspecialchars($p['phone'] ?: '—') ?></td>
                <td><?= date('d M Y', strtotime($p['created_at'])) ?></td>
                <td><span class="pill pill-blue"><?= $p['active_loans'] ?></span></td>
                <td><?= $p['total_requests'] ?></td>
                <td><span class="pill <?= $p['is_active']?'pill-green':'pill-red' ?>"><?= $p['is_active']?'Active':'Inactive' ?></span></td>
                <td class="action-btns">
                    <button class="btn-danger btn-sm" onclick="deletePlayer(<?= $p['id'] ?>)">🗑️ Remove</button>
                </td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="9"><div class="empty-state"><div class="empty-icon">👥</div><p>No players registered yet.</p></div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
