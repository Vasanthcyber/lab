<?php
define('PAGE_TITLE', 'Reports');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('admin');

$db = getDB();

// By category
$byCategory = $db->query("
    SELECT category,
        COUNT(*) as item_types,
        SUM(total_units) as total,
        SUM(available_units) as available,
        SUM(total_units - available_units - damaged_units) as issued
    FROM equipment WHERE is_active=1
    GROUP BY category ORDER BY total DESC
")->fetchAll();

// Player activity
$playerActivity = $db->query("
    SELECT u.name, u.username,
        COUNT(r.id) as total,
        SUM(r.status='approved') as approved,
        SUM(r.status='returned') as returned,
        SUM(r.status='rejected') as rejected,
        SUM(r.status='pending') as pending
    FROM users u
    LEFT JOIN equipment_requests r ON r.user_id = u.id
    WHERE u.role='player'
    GROUP BY u.id ORDER BY total DESC
")->fetchAll();

// Most requested
$mostRequested = $db->query("
    SELECT e.name, e.emoji, e.category,
        COUNT(r.id) as requests,
        SUM(r.status='returned') as returned,
        e.total_units, e.available_units,
        ROUND(((e.total_units - e.available_units - e.damaged_units) / NULLIF(e.total_units,0)) * 100) as utilization
    FROM equipment e
    LEFT JOIN equipment_requests r ON r.equipment_id = e.id
    WHERE e.is_active=1
    GROUP BY e.id ORDER BY requests DESC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Reports</h2><p>Analytics and inventory insights</p></div>
</div>

<div class="section-row">
    <div class="table-card">
        <div class="table-header"><h3>📂 Equipment by Category</h3></div>
        <table>
            <thead><tr><th>Category</th><th>Item Types</th><th>Total Units</th><th>Available</th><th>Issued</th></tr></thead>
            <tbody>
            <?php foreach ($byCategory as $c): ?>
                <tr>
                    <td><span class="pill pill-blue"><?= $c['category'] ?></span></td>
                    <td><?= $c['item_types'] ?></td>
                    <td class="td-mono"><?= $c['total'] ?></td>
                    <td class="td-mono" style="color:var(--green)"><?= $c['available'] ?></td>
                    <td class="td-mono" style="color:var(--orange)"><?= $c['issued'] ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="table-card">
        <div class="table-header"><h3>👥 Player Activity</h3></div>
        <table>
            <thead><tr><th>Player</th><th>Total</th><th>Approved</th><th>Returned</th><th>Rejected</th><th>Pending</th></tr></thead>
            <tbody>
            <?php foreach ($playerActivity as $p): ?>
                <tr>
                    <td><b><?= htmlspecialchars($p['name']) ?></b><div class="td-sub">@<?= $p['username'] ?></div></td>
                    <td><?= $p['total'] ?></td>
                    <td style="color:var(--blue)"><?= $p['approved'] ?></td>
                    <td style="color:var(--green)"><?= $p['returned'] ?></td>
                    <td style="color:var(--red)"><?= $p['rejected'] ?></td>
                    <td style="color:var(--orange)"><?= $p['pending'] ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="table-card">
    <div class="table-header"><h3>🏏 Most Requested Equipment</h3></div>
    <table>
        <thead><tr><th>#</th><th>Equipment</th><th>Category</th><th>Total Requests</th><th>Times Returned</th><th>Total Units</th><th>Utilization</th></tr></thead>
        <tbody>
        <?php foreach ($mostRequested as $i => $e):
            $util = $e['utilization'] ?? 0;
            $barColor = $util > 70 ? 'var(--red)' : ($util > 40 ? 'var(--orange)' : 'var(--green)');
        ?>
            <tr>
                <td class="td-mono"><?= $i+1 ?></td>
                <td><b><?= $e['emoji'] ?> <?= htmlspecialchars($e['name']) ?></b></td>
                <td><span class="pill pill-blue"><?= $e['category'] ?></span></td>
                <td><?= $e['requests'] ?></td>
                <td><?= $e['returned'] ?></td>
                <td><?= $e['total_units'] ?></td>
                <td style="width:160px">
                    <div style="display:flex;align-items:center;gap:8px">
                        <div class="progress-bar" style="flex:1"><div class="progress-fill" style="width:<?= $util ?>%;background:<?= $barColor ?>"></div></div>
                        <span class="td-mono"><?= $util ?>%</span>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
