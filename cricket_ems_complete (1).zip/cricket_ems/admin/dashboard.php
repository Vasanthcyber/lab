<?php
define('PAGE_TITLE', 'Dashboard');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('admin');

$db = getDB();

// Stats
$totalUnits    = $db->query("SELECT SUM(total_units) FROM equipment WHERE is_active=1")->fetchColumn() ?: 0;
$availUnits    = $db->query("SELECT SUM(available_units) FROM equipment WHERE is_active=1")->fetchColumn() ?: 0;
$issuedUnits   = $db->query("SELECT SUM(total_units - available_units - damaged_units) FROM equipment WHERE is_active=1")->fetchColumn() ?: 0;
$damagedUnits  = $db->query("SELECT SUM(damaged_units) FROM equipment WHERE is_active=1")->fetchColumn() ?: 0;
$pendingCount  = $db->query("SELECT COUNT(*) FROM equipment_requests WHERE status='pending'")->fetchColumn() ?: 0;

// Pending requests
$pendingReqs = $db->query("
    SELECT r.*, u.name as player_name, e.name as equip_name, e.emoji
    FROM equipment_requests r
    JOIN users u ON r.user_id = u.id
    JOIN equipment e ON r.equipment_id = e.id
    WHERE r.status='pending' ORDER BY r.created_at DESC LIMIT 5
")->fetchAll();

// Low stock
$lowStock = $db->query("SELECT * FROM equipment WHERE available_units <= min_stock_level AND is_active=1")->fetchAll();

// Recent activity
$recentActivity = $db->query("
    SELECT r.*, u.name as player_name, e.name as equip_name, e.emoji
    FROM equipment_requests r
    JOIN users u ON r.user_id = u.id
    JOIN equipment e ON r.equipment_id = e.id
    ORDER BY r.updated_at DESC LIMIT 8
")->fetchAll();

// Stock overview
$stockOverview = $db->query("SELECT * FROM equipment WHERE is_active=1 ORDER BY available_units ASC LIMIT 6")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div>
        <h2>Dashboard</h2>
        <p>Welcome back, <?= htmlspecialchars($user['name']) ?> — <?= date('l, d F Y') ?></p>
    </div>
</div>

<?php if ($lowStock): ?>
<div class="alert-banner">
    ⚠️ <b><?= count($lowStock) ?> item<?= count($lowStock)>1?'s':'' ?> below minimum stock:</b>
    <?php foreach ($lowStock as $ls): ?>
        <span class="pill pill-red"><?= $ls['emoji'] ?> <?= htmlspecialchars($ls['name']) ?> (<?= $ls['available_units'] ?> left)</span>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="stat-grid">
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">📦</span><span class="badge badge-blue">Total</span></div><div class="stat-num"><?= $totalUnits ?></div><div class="stat-label">Total Equipment Units</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">✅</span><span class="badge badge-green">Available</span></div><div class="stat-num"><?= $availUnits ?></div><div class="stat-label">Units Available</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">🔄</span><span class="badge badge-orange">Issued</span></div><div class="stat-num"><?= $issuedUnits ?></div><div class="stat-label">Currently Issued</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">🔴</span><span class="badge badge-red">Damaged</span></div><div class="stat-num"><?= $damagedUnits ?></div><div class="stat-label">Damaged / Repair</div></div>
</div>

<div class="section-row">
    <!-- Pending Requests -->
    <div class="table-card">
        <div class="table-header">
            <h3>📋 Pending Requests <span class="badge badge-orange"><?= $pendingCount ?></span></h3>
            <a href="<?= SITE_URL ?>/admin/requests.php" class="btn-secondary btn-sm">View All</a>
        </div>
        <table>
            <thead><tr><th>Player</th><th>Equipment</th><th>Qty</th><th>Date</th><th>Action</th></tr></thead>
            <tbody>
            <?php if ($pendingReqs): foreach ($pendingReqs as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['player_name']) ?></td>
                    <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                    <td><?= $r['quantity'] ?></td>
                    <td><?= date('d M', strtotime($r['request_date'])) ?></td>
                    <td class="action-btns">
                        <button class="btn-success btn-sm" onclick="approveRequest(<?= $r['id'] ?>)">Approve</button>
                        <button class="btn-danger btn-sm" onclick="rejectRequest(<?= $r['id'] ?>)">Reject</button>
                    </td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="5"><div class="empty-state"><p>No pending requests 🎉</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Stock Overview -->
    <div class="table-card">
        <div class="table-header"><h3>📊 Stock Overview</h3></div>
        <table>
            <thead><tr><th>Equipment</th><th>Avail</th><th>Issued</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($stockOverview as $e):
                $pct = $e['total_units'] > 0 ? round($e['available_units'] / $e['total_units'] * 100) : 0;
                $pillClass = $e['available_units'] <= $e['min_stock_level'] ? 'pill-red' : ($e['available_units'] <= $e['min_stock_level']*2 ? 'pill-orange' : 'pill-green');
                $label = $e['available_units'] <= $e['min_stock_level'] ? 'Low Stock' : ($e['available_units'] <= $e['min_stock_level']*2 ? 'Moderate' : 'Good');
                $issued = $e['total_units'] - $e['available_units'] - $e['damaged_units'];
            ?>
                <tr>
                    <td><?= $e['emoji'] ?> <?= htmlspecialchars($e['name']) ?></td>
                    <td><?= $e['available_units'] ?></td>
                    <td><?= $issued ?></td>
                    <td><span class="pill <?= $pillClass ?>"><?= $label ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Recent Activity -->
<div class="table-card">
    <div class="table-header"><h3>🕒 Recent Activity</h3></div>
    <table>
        <thead><tr><th>Player</th><th>Equipment</th><th>Qty</th><th>Request Date</th><th>Status</th><th>Notes</th></tr></thead>
        <tbody>
        <?php foreach ($recentActivity as $r):
            $pills = ['approved'=>'pill-blue','pending'=>'pill-orange','returned'=>'pill-green','rejected'=>'pill-red','cancelled'=>'pill-grey'];
        ?>
            <tr>
                <td><?= htmlspecialchars($r['player_name']) ?></td>
                <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                <td><?= $r['quantity'] ?></td>
                <td><?= date('d M Y', strtotime($r['request_date'])) ?></td>
                <td><span class="pill <?= $pills[$r['status']] ?>"><?= $r['status'] ?></span></td>
                <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($r['notes'] ?: '—') ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
