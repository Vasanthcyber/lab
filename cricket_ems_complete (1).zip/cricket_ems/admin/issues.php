<?php
define('PAGE_TITLE', 'Issues & Returns');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('admin');

$db = getDB();

$activeIssues = $db->query("
    SELECT r.*, u.name as player_name, e.name as equip_name, e.emoji
    FROM equipment_requests r
    JOIN users u ON r.user_id = u.id
    JOIN equipment e ON r.equipment_id = e.id
    WHERE r.status = 'approved'
    ORDER BY r.issue_date DESC
")->fetchAll();

$returnedItems = $db->query("
    SELECT r.*, u.name as player_name, e.name as equip_name, e.emoji
    FROM equipment_requests r
    JOIN users u ON r.user_id = u.id
    JOIN equipment e ON r.equipment_id = e.id
    WHERE r.status = 'returned'
    ORDER BY r.return_date DESC LIMIT 30
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Issues & Returns</h2><p>Track equipment issued to players and record returns</p></div>
    <button class="btn-primary" onclick="showDirectIssue()">+ Issue Equipment</button>
</div>

<div class="section-row">
    <!-- Active Issues -->
    <div class="table-card">
        <div class="table-header">
            <h3>🔄 Currently Issued <span class="badge badge-orange"><?= count($activeIssues) ?></span></h3>
        </div>
        <table>
            <thead><tr><th>Player</th><th>Equipment</th><th>Qty</th><th>Issued</th><th>Due</th><th>Action</th></tr></thead>
            <tbody>
            <?php if ($activeIssues): foreach ($activeIssues as $r):
                $overdue = $r['due_date'] && strtotime($r['due_date']) < time();
            ?>
                <tr>
                    <td><?= htmlspecialchars($r['player_name']) ?></td>
                    <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                    <td><?= $r['quantity'] ?></td>
                    <td><?= date('d M', strtotime($r['issue_date'])) ?></td>
                    <td class="<?= $overdue?'overdue':'' ?>"><?= $r['due_date']?date('d M Y',strtotime($r['due_date'])):'—' ?><?= $overdue?' ⚠️':'' ?></td>
                    <td><button class="btn-success btn-sm" onclick="returnEquipment(<?= $r['id'] ?>)">↩ Return</button></td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="6"><div class="empty-state"><div class="empty-icon">✅</div><p>No active issues</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Returned -->
    <div class="table-card">
        <div class="table-header"><h3>✅ Returned Items</h3></div>
        <table>
            <thead><tr><th>Player</th><th>Equipment</th><th>Qty</th><th>Issue Date</th><th>Returned</th></tr></thead>
            <tbody>
            <?php if ($returnedItems): foreach ($returnedItems as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['player_name']) ?></td>
                    <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                    <td><?= $r['quantity'] ?></td>
                    <td><?= $r['issue_date']?date('d M Y',strtotime($r['issue_date'])):'—' ?></td>
                    <td><?= $r['return_date']?date('d M Y',strtotime($r['return_date'])):'—' ?></td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="5"><div class="empty-state"><p>No returns yet</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
