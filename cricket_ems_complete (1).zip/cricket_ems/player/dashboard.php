<?php
define('PAGE_TITLE', 'Dashboard');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('player');

$db = getDB();
$uid = $user['id'];

$activeLoans = $db->prepare("
    SELECT r.*, e.name as equip_name, e.emoji
    FROM equipment_requests r JOIN equipment e ON r.equipment_id = e.id
    WHERE r.user_id = ? AND r.status='approved' ORDER BY r.issue_date DESC
");
$activeLoans->execute([$uid]);
$activeLoans = $activeLoans->fetchAll();

$pendingReqs = $db->prepare("
    SELECT r.*, e.name as equip_name, e.emoji
    FROM equipment_requests r JOIN equipment e ON r.equipment_id = e.id
    WHERE r.user_id = ? AND r.status='pending' ORDER BY r.request_date DESC
");
$pendingReqs->execute([$uid]);
$pendingReqs = $pendingReqs->fetchAll();

$totalReqs = $db->prepare("SELECT COUNT(*) FROM equipment_requests WHERE user_id=?");
$totalReqs->execute([$uid]);
$totalReqs = $totalReqs->fetchColumn();

$availTypes = $db->query("SELECT COUNT(*) FROM equipment WHERE available_units > 0 AND is_active=1")->fetchColumn();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Dashboard</h2><p>Welcome back, <?= htmlspecialchars($user['name']) ?>! 🏏</p></div>
    <a href="<?= SITE_URL ?>/player/browse.php" class="btn-primary">Browse Equipment</a>
</div>

<div class="stat-grid">
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">🔄</span><span class="badge badge-orange">Active</span></div><div class="stat-num"><?= count($activeLoans) ?></div><div class="stat-label">Items with Me</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">⏳</span><span class="badge badge-blue">Pending</span></div><div class="stat-num"><?= count($pendingReqs) ?></div><div class="stat-label">Awaiting Approval</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">📋</span><span class="badge badge-green">Total</span></div><div class="stat-num"><?= $totalReqs ?></div><div class="stat-label">All-time Requests</div></div>
    <div class="stat-card"><div class="stat-card-top"><span class="stat-icon">✅</span><span class="badge badge-accent">Available</span></div><div class="stat-num"><?= $availTypes ?></div><div class="stat-label">Equipment Types in Stock</div></div>
</div>

<div class="section-row">
    <div class="table-card">
        <div class="table-header"><h3>Currently with Me</h3></div>
        <table>
            <thead><tr><th>Equipment</th><th>Qty</th><th>Issued</th><th>Due</th></tr></thead>
            <tbody>
            <?php if ($activeLoans): foreach ($activeLoans as $r):
                $overdue = $r['due_date'] && strtotime($r['due_date']) < time();
            ?>
                <tr>
                    <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                    <td><?= $r['quantity'] ?></td>
                    <td><?= date('d M Y', strtotime($r['issue_date'])) ?></td>
                    <td class="<?= $overdue?'overdue':'' ?>"><?= $r['due_date']?date('d M Y',strtotime($r['due_date'])):'—' ?><?= $overdue?' ⚠️':'' ?></td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="4"><div class="empty-state"><p>No active equipment</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="table-card">
        <div class="table-header"><h3>Pending Requests</h3></div>
        <table>
            <thead><tr><th>Equipment</th><th>Qty</th><th>Requested</th></tr></thead>
            <tbody>
            <?php if ($pendingReqs): foreach ($pendingReqs as $r): ?>
                <tr>
                    <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                    <td><?= $r['quantity'] ?></td>
                    <td><?= date('d M Y', strtotime($r['request_date'])) ?></td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="3"><div class="empty-state"><p>No pending requests</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
