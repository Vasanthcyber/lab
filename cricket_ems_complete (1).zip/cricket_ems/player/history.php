<?php
define('PAGE_TITLE', 'Usage History');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('player');

$db = getDB();
$uid = $user['id'];

$stmt = $db->prepare("
    SELECT r.*, e.name as equip_name, e.emoji
    FROM equipment_requests r JOIN equipment e ON r.equipment_id = e.id
    WHERE r.user_id = ? AND r.status IN ('returned','approved')
    ORDER BY r.issue_date DESC
");
$stmt->execute([$uid]);
$history = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Usage History</h2><p>Your complete equipment usage log</p></div>
</div>

<div class="table-card">
    <div class="table-header"><h3>History (<?= count($history) ?> entries)</h3></div>
    <table>
        <thead><tr><th>Equipment</th><th>Qty</th><th>Issued</th><th>Due Date</th><th>Returned</th><th>Duration</th><th>Status</th></tr></thead>
        <tbody>
        <?php if ($history): foreach ($history as $r):
            $duration = '—';
            if ($r['issue_date'] && $r['return_date']) {
                $days = (int)((strtotime($r['return_date']) - strtotime($r['issue_date'])) / 86400);
                $duration = $days . ' day' . ($days!==1?'s':'');
            } elseif ($r['issue_date']) {
                $days = (int)((time() - strtotime($r['issue_date'])) / 86400);
                $duration = $days . 'd (ongoing)';
            }
        ?>
            <tr>
                <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                <td><?= $r['quantity'] ?></td>
                <td><?= $r['issue_date']?date('d M Y',strtotime($r['issue_date'])):'—' ?></td>
                <td><?= $r['due_date']?date('d M Y',strtotime($r['due_date'])):'—' ?></td>
                <td><?= $r['return_date']?date('d M Y',strtotime($r['return_date'])):'—' ?></td>
                <td class="td-mono"><?= $duration ?></td>
                <td><span class="pill <?= $r['status']==='returned'?'pill-green':'pill-blue' ?>"><?= $r['status'] ?></span></td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="7"><div class="empty-state"><div class="empty-icon">📖</div><p>No usage history yet. <a href="<?= SITE_URL ?>/player/browse.php" style="color:var(--accent)">Browse equipment</a> to get started!</p></div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
