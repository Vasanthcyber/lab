<?php
define('PAGE_TITLE', 'My Requests');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('player');

$db = getDB();
$uid = $user['id'];

$stmt = $db->prepare("
    SELECT r.*, e.name as equip_name, e.emoji
    FROM equipment_requests r JOIN equipment e ON r.equipment_id = e.id
    WHERE r.user_id = ? ORDER BY r.created_at DESC
");
$stmt->execute([$uid]);
$requests = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>My Requests</h2><p>Track all your equipment requests</p></div>
    <a href="<?= SITE_URL ?>/player/browse.php" class="btn-primary">+ New Request</a>
</div>

<div class="table-card">
    <div class="table-header">
        <h3>All My Requests (<?= count($requests) ?>)</h3>
        <input class="search-input" placeholder="🔍 Search..." oninput="filterTable(this,'myReqTbody')">
    </div>
    <table>
        <thead><tr><th>Equipment</th><th>Qty</th><th>Requested</th><th>Status</th><th>Issue Date</th><th>Due</th><th>Returned</th><th>Notes</th><th>Admin Notes</th></tr></thead>
        <tbody id="myReqTbody">
        <?php if ($requests): foreach ($requests as $r):
            $pills = ['approved'=>'pill-blue','pending'=>'pill-orange','returned'=>'pill-green','rejected'=>'pill-red','cancelled'=>'pill-grey'];
            $overdue = $r['status']==='approved' && $r['due_date'] && strtotime($r['due_date']) < time();
        ?>
            <tr>
                <td><?= $r['emoji'] ?> <?= htmlspecialchars($r['equip_name']) ?></td>
                <td><?= $r['quantity'] ?></td>
                <td><?= date('d M Y', strtotime($r['request_date'])) ?></td>
                <td><span class="pill <?= $pills[$r['status']] ?>"><?= $r['status'] ?></span></td>
                <td><?= $r['issue_date']?date('d M Y',strtotime($r['issue_date'])):'—' ?></td>
                <td class="<?= $overdue?'overdue':'' ?>"><?= $r['due_date']?date('d M Y',strtotime($r['due_date'])):'—' ?></td>
                <td><?= $r['return_date']?date('d M Y',strtotime($r['return_date'])):'—' ?></td>
                <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($r['notes']?:'—') ?></td>
                <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($r['admin_notes']?:'—') ?></td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="9"><div class="empty-state"><div class="empty-icon">📋</div><p>No requests yet. <a href="<?= SITE_URL ?>/player/browse.php" style="color:var(--accent)">Browse equipment</a> to make your first request!</p></div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
