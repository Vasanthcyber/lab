<?php
define('PAGE_TITLE', 'Browse Equipment');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin('player');

$db = getDB();
$equipment = $db->query("SELECT * FROM equipment WHERE is_active=1 ORDER BY category, name")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<meta name="csrf" content="<?= csrfToken() ?>">
<script>const BASE_URL = '<?= SITE_URL ?>';</script>

<div class="page-header">
    <div><h2>Browse Equipment</h2><p>Request equipment for practice or match use</p></div>
</div>

<!-- Category Filter -->
<div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap">
    <button class="btn-secondary btn-sm cat-filter active" data-cat="all" onclick="filterCat('all',this)">All</button>
    <?php $cats = array_unique(array_column($equipment,'category')); foreach ($cats as $c): ?>
    <button class="btn-secondary btn-sm cat-filter" data-cat="<?= $c ?>" onclick="filterCat('<?= $c ?>',this)"><?= $c ?></button>
    <?php endforeach; ?>
</div>

<div class="equipment-grid" id="equipGrid">
<?php foreach ($equipment as $e):
    $avail = $e['available_units'] > 0;
    $stockClass = !$avail ? 'stock-out' : ($e['available_units'] <= $e['min_stock_level'] ? 'stock-low' : 'stock-ok');
    $pct = $e['total_units'] > 0 ? round($e['available_units']/$e['total_units']*100) : 0;
    $barColor = !$avail ? 'var(--red)' : ($e['available_units'] <= $e['min_stock_level'] ? 'var(--orange)' : 'var(--green)');
?>
<div class="equipment-card" data-cat="<?= $e['category'] ?>">
    <div class="equipment-card-img"><?= $e['emoji'] ?></div>
    <div class="equipment-card-body">
        <h4><?= htmlspecialchars($e['name']) ?></h4>
        <p><?= htmlspecialchars($e['description'] ?: 'Cricket equipment') ?></p>
        <span class="pill pill-blue"><?= $e['category'] ?></span>
        <div class="equipment-card-footer">
            <div>
                <div style="font-family:'JetBrains Mono',monospace;font-size:11px;color:<?= !$avail?'var(--red)':($e['available_units']<=$e['min_stock_level']?'var(--orange)':'var(--green)') ?>">
                    <?= $avail ? $e['available_units'] . ' available' : 'Out of stock' ?>
                </div>
                <div class="progress-bar" style="width:90px;margin-top:5px"><div class="progress-fill" style="width:<?= $pct ?>%;background:<?= $barColor ?>"></div></div>
            </div>
            <?php if ($avail): ?>
                <button class="btn-primary btn-sm" onclick="showRequestEquipment(<?= $e['id'] ?>, '<?= addslashes($e['name']) ?>', '<?= $e['emoji'] ?>', <?= $e['available_units'] ?>)">Request</button>
            <?php else: ?>
                <span style="font-size:11px;color:var(--red)">Unavailable</span>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; ?>
</div>

<style>
.stock-ok{color:var(--green)}.stock-low{color:var(--orange)}.stock-out{color:var(--red)}
.cat-filter.active{background:var(--accent);color:var(--bg);border-color:var(--accent)}
</style>
<script>
function filterCat(cat, btn) {
    document.querySelectorAll('.cat-filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('#equipGrid .equipment-card').forEach(card => {
        card.style.display = (cat==='all' || card.dataset.cat===cat) ? '' : 'none';
    });
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
