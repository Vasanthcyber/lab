<?php // includes/footer.php ?>
</main><!-- end .main-content -->
</div><!-- end .app-layout -->

<!-- ── MODAL OVERLAY ── -->
<div class="modal-overlay" id="modalOverlay">
    <div class="modal" id="modalBox">
        <div class="modal-header">
            <h3 id="modalTitle">Modal</h3>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        <div id="modalBody"></div>
    </div>
</div>

<!-- ── TOAST ── -->
<div class="toast-container" id="toastContainer"></div>

<script src="<?= SITE_URL ?>/assets/js/app.js"></script>
</body>
</html>
