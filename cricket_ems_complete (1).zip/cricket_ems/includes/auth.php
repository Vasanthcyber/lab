<?php
// ============================================================
// includes/auth.php — Authentication & Session Helpers
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

// ── START / VALIDATE SESSION ─────────────────────────────────
function requireLogin(string $role = ''): array {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . SITE_URL . '/index.php');
        exit;
    }
    // Check session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
        session_unset(); session_destroy();
        header('Location: ' . SITE_URL . '/index.php?timeout=1');
        exit;
    }
    $_SESSION['last_activity'] = time();

    if ($role && $_SESSION['user_role'] !== $role) {
        header('Location: ' . SITE_URL . '/index.php?denied=1');
        exit;
    }
    return ['id' => $_SESSION['user_id'], 'name' => $_SESSION['user_name'], 'role' => $_SESSION['user_role']];
}

function isLoggedIn(): bool {
    return !empty($_SESSION['user_id']);
}

function currentUser(): ?array {
    if (!isLoggedIn()) return null;
    return ['id' => $_SESSION['user_id'], 'name' => $_SESSION['user_name'], 'role' => $_SESSION['user_role']];
}

// ── CSRF ─────────────────────────────────────────────────────
function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrf(): void {
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        die(json_encode(['success' => false, 'message' => 'CSRF token mismatch.']));
    }
}

// ── RESPONSE HELPERS ─────────────────────────────────────────
function jsonResponse(bool $success, string $message, array $data = []): void {
    header('Content-Type: application/json');
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $data));
    exit;
}

function sanitize(string $val): string {
    return htmlspecialchars(trim($val), ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void {
    header("Location: $url"); exit;
}

function flashSet(string $type, string $msg): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $msg];
}

function flashGet(): ?array {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
