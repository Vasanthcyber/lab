<?php
// includes/header.php — Shared HTML head + sidebar
if (!defined('PAGE_TITLE')) define('PAGE_TITLE', 'CricketVault');
$user = currentUser();
$flash = flashGet();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= PAGE_TITLE ?> — CricketVault EMS</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>

<?php if ($flash): ?>
<div class="flash-banner flash-<?= $flash['type'] ?>" id="flashBanner">
    <?= $flash['type'] === 'success' ? '✅' : ($flash['type'] === 'error' ? '❌' : 'ℹ️') ?>
    <?= htmlspecialchars($flash['message']) ?>
    <button onclick="this.parentElement.remove()">✕</button>
</div>
<?php endif; ?>

<div class="app-layout">
<!-- ── SIDEBAR ── -->
<aside class="sidebar">
    <div class="sidebar-logo">
        <h1>Cricket<span>Vault</span></h1>
        <p>Equipment System</p>
    </div>
    <div class="sidebar-user">
        <div class="user-avatar"><?= strtoupper(substr($user['name'],0,1)) ?></div>
        <div class="user-info">
            <p><?= htmlspecialchars($user['name']) ?></p>
            <span><?= $user['role'] === 'admin' ? 'Administrator' : 'Player' ?></span>
        </div>
    </div>
    <nav class="sidebar-nav">
<?php if ($user['role'] === 'admin'): ?>
        <div class="nav-section">Overview</div>
        <a href="<?= SITE_URL ?>/admin/dashboard.php" class="nav-item <?= (PAGE_TITLE==='Dashboard')?'active':'' ?>"><span class="nav-icon">📊</span> Dashboard</a>
        <div class="nav-section">Equipment</div>
        <a href="<?= SITE_URL ?>/admin/equipment.php" class="nav-item <?= (PAGE_TITLE==='Equipment')?'active':'' ?>"><span class="nav-icon">🏏</span> Equipment List</a>
        <a href="<?= SITE_URL ?>/admin/inventory.php" class="nav-item <?= (PAGE_TITLE==='Inventory')?'active':'' ?>"><span class="nav-icon">📦</span> Inventory</a>
        <div class="nav-section">Operations</div>
        <a href="<?= SITE_URL ?>/admin/requests.php" class="nav-item <?= (PAGE_TITLE==='Requests')?'active':'' ?>">
            <span class="nav-icon">📋</span> Requests
            <?php
            $pdb = getDB();
            $pc = $pdb->query("SELECT COUNT(*) FROM equipment_requests WHERE status='pending'")->fetchColumn();
            if ($pc > 0): ?><span class="notif-dot"><?= $pc ?></span><?php endif; ?>
        </a>
        <a href="<?= SITE_URL ?>/admin/issues.php" class="nav-item <?= (PAGE_TITLE==='Issues & Returns')?'active':'' ?>"><span class="nav-icon">🔄</span> Issues & Returns</a>
        <div class="nav-section">People</div>
        <a href="<?= SITE_URL ?>/admin/players.php" class="nav-item <?= (PAGE_TITLE==='Players')?'active':'' ?>"><span class="nav-icon">👥</span> Players</a>
        <div class="nav-section">Reports</div>
        <a href="<?= SITE_URL ?>/admin/reports.php" class="nav-item <?= (PAGE_TITLE==='Reports')?'active':'' ?>"><span class="nav-icon">📈</span> Reports</a>
<?php else: ?>
        <div class="nav-section">My Panel</div>
        <a href="<?= SITE_URL ?>/player/dashboard.php" class="nav-item <?= (PAGE_TITLE==='Dashboard')?'active':'' ?>"><span class="nav-icon">🏠</span> Dashboard</a>
        <a href="<?= SITE_URL ?>/player/browse.php" class="nav-item <?= (PAGE_TITLE==='Browse Equipment')?'active':'' ?>"><span class="nav-icon">🏏</span> Browse Equipment</a>
        <a href="<?= SITE_URL ?>/player/requests.php" class="nav-item <?= (PAGE_TITLE==='My Requests')?'active':'' ?>"><span class="nav-icon">📋</span> My Requests</a>
        <a href="<?= SITE_URL ?>/player/history.php" class="nav-item <?= (PAGE_TITLE==='Usage History')?'active':'' ?>"><span class="nav-icon">📖</span> Usage History</a>
<?php endif; ?>
    </nav>
    <div class="sidebar-bottom">
        <a href="<?= SITE_URL ?>/logout.php" class="btn-logout">↩ Logout</a>
    </div>
</aside>

<!-- ── MAIN ── -->
<main class="main-content">
