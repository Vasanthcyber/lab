<?php
// api/equipment.php — Equipment CRUD API
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
$user = requireLogin('admin');
verifyCsrf();

$db     = getDB();
$action = $_POST['action'] ?? '';

switch ($action) {

    // ── GET SINGLE EQUIPMENT ─────────────────────────────────
    case 'get':
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $db->prepare("SELECT * FROM equipment WHERE id=? AND is_active=1");
        $stmt->execute([$id]);
        $eq = $stmt->fetch();
        if (!$eq) jsonResponse(false, 'Equipment not found.');
        jsonResponse(true, 'OK', ['data' => $eq]);

    // ── LIST FOR RESTOCK ─────────────────────────────────────
    case 'list_for_restock':
        $items = $db->query("SELECT id, name, emoji, available_units FROM equipment WHERE is_active=1 ORDER BY name")->fetchAll();
        jsonResponse(true, 'OK', ['items' => $items]);

    // ── ADD EQUIPMENT ────────────────────────────────────────
    case 'add_equipment':
        $name       = trim($_POST['name'] ?? '');
        $category   = $_POST['category'] ?? '';
        $emoji      = trim($_POST['emoji'] ?? '🏏');
        $desc       = trim($_POST['description'] ?? '');
        $total      = max(1, (int)($_POST['total_units'] ?? 0));
        $minStock   = max(1, (int)($_POST['min_stock_level'] ?? 3));
        $validCats  = ['Batting','Fielding','Safety','General','Training','Bowling'];

        if (empty($name)) jsonResponse(false, 'Equipment name is required.');
        if (!in_array($category, $validCats)) jsonResponse(false, 'Invalid category.');

        $stmt = $db->prepare("INSERT INTO equipment (name, category, emoji, description, total_units, available_units, min_stock_level) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$name, $category, $emoji ?: '📦', $desc, $total, $total, $minStock]);
        $newId = $db->lastInsertId();

        // Log stock
        $db->prepare("INSERT INTO stock_log (equipment_id, change_type, quantity_change, new_available, logged_by, notes) VALUES (?,?,?,?,?,?)")
           ->execute([$newId, 'restock', $total, $total, $user['id'], 'Initial stock']);

        jsonResponse(true, "Equipment '$name' added successfully.");

    // ── EDIT EQUIPMENT ───────────────────────────────────────
    case 'edit_equipment':
        $id         = (int)($_POST['id'] ?? 0);
        $name       = trim($_POST['name'] ?? '');
        $category   = $_POST['category'] ?? '';
        $emoji      = trim($_POST['emoji'] ?? '');
        $desc       = trim($_POST['description'] ?? '');
        $newTotal   = max(1, (int)($_POST['total_units'] ?? 0));
        $minStock   = max(1, (int)($_POST['min_stock_level'] ?? 3));

        if (empty($name)) jsonResponse(false, 'Equipment name is required.');

        $stmt = $db->prepare("SELECT * FROM equipment WHERE id=? AND is_active=1");
        $stmt->execute([$id]);
        $current = $stmt->fetch();
        if (!$current) jsonResponse(false, 'Equipment not found.');

        $diff = $newTotal - $current['total_units'];
        $newAvail = max(0, $current['available_units'] + $diff);

        $db->prepare("UPDATE equipment SET name=?, category=?, emoji=?, description=?, total_units=?, available_units=?, min_stock_level=? WHERE id=?")
           ->execute([$name, $category, $emoji ?: $current['emoji'], $desc, $newTotal, $newAvail, $minStock, $id]);

        if ($diff !== 0) {
            $db->prepare("INSERT INTO stock_log (equipment_id, change_type, quantity_change, new_available, logged_by, notes) VALUES (?,?,?,?,?,?)")
               ->execute([$id, 'restock', $diff, $newAvail, $user['id'], 'Stock updated via edit']);
        }

        jsonResponse(true, "Equipment updated successfully.");

    // ── DELETE EQUIPMENT ─────────────────────────────────────
    case 'delete':
        $id = (int)($_POST['id'] ?? 0);
        // Soft delete: mark inactive
        $stmt = $db->prepare("UPDATE equipment SET is_active=0 WHERE id=?");
        $stmt->execute([$id]);
        jsonResponse(true, 'Equipment deleted.');

    // ── MARK DAMAGED ─────────────────────────────────────────
    case 'mark_damaged':
        $id     = (int)($_POST['id'] ?? 0);
        $qty    = max(1, (int)($_POST['quantity'] ?? 1));
        $reason = trim($_POST['reason'] ?? '');

        $stmt = $db->prepare("SELECT * FROM equipment WHERE id=? AND is_active=1");
        $stmt->execute([$id]);
        $eq = $stmt->fetch();
        if (!$eq) jsonResponse(false, 'Equipment not found.');
        if ($qty > $eq['available_units']) jsonResponse(false, "Only {$eq['available_units']} units available.");

        $newAvail   = $eq['available_units'] - $qty;
        $newDamaged = $eq['damaged_units'] + $qty;

        $db->prepare("UPDATE equipment SET available_units=?, damaged_units=? WHERE id=?")
           ->execute([$newAvail, $newDamaged, $id]);
        $db->prepare("INSERT INTO damage_log (equipment_id, quantity, action, reason, logged_by) VALUES (?,?,?,?,?)")
           ->execute([$id, $qty, 'damaged', $reason, $user['id']]);
        $db->prepare("INSERT INTO stock_log (equipment_id, change_type, quantity_change, new_available, logged_by, notes) VALUES (?,?,?,?,?,?)")
           ->execute([$id, 'damage', -$qty, $newAvail, $user['id'], $reason]);

        jsonResponse(true, "$qty unit(s) marked as damaged.");

    // ── MARK REPAIRED ────────────────────────────────────────
    case 'mark_repaired':
        $id  = (int)($_POST['id'] ?? 0);
        $qty = max(1, (int)($_POST['quantity'] ?? 1));

        $stmt = $db->prepare("SELECT * FROM equipment WHERE id=? AND is_active=1");
        $stmt->execute([$id]);
        $eq = $stmt->fetch();
        if (!$eq) jsonResponse(false, 'Equipment not found.');
        if ($qty > $eq['damaged_units']) jsonResponse(false, "Only {$eq['damaged_units']} damaged units.");

        $newAvail   = $eq['available_units'] + $qty;
        $newDamaged = $eq['damaged_units'] - $qty;

        $db->prepare("UPDATE equipment SET available_units=?, damaged_units=? WHERE id=?")
           ->execute([$newAvail, $newDamaged, $id]);
        $db->prepare("INSERT INTO damage_log (equipment_id, quantity, action, reason, logged_by) VALUES (?,?,?,?,?)")
           ->execute([$id, $qty, 'repaired', 'Repaired and returned to stock', $user['id']]);
        $db->prepare("INSERT INTO stock_log (equipment_id, change_type, quantity_change, new_available, logged_by, notes) VALUES (?,?,?,?,?,?)")
           ->execute([$id, 'repair', $qty, $newAvail, $user['id'], 'Repaired']);

        jsonResponse(true, "$qty unit(s) marked as repaired and restocked.");

    // ── RESTOCK ──────────────────────────────────────────────
    case 'restock':
        $id    = (int)($_POST['id'] ?? 0);
        $qty   = max(1, (int)($_POST['quantity'] ?? 0));
        $notes = trim($_POST['notes'] ?? '');

        $stmt = $db->prepare("SELECT * FROM equipment WHERE id=? AND is_active=1");
        $stmt->execute([$id]);
        $eq = $stmt->fetch();
        if (!$eq) jsonResponse(false, 'Equipment not found.');

        $newTotal = $eq['total_units'] + $qty;
        $newAvail = $eq['available_units'] + $qty;

        $db->prepare("UPDATE equipment SET total_units=?, available_units=? WHERE id=?")
           ->execute([$newTotal, $newAvail, $id]);
        $db->prepare("INSERT INTO stock_log (equipment_id, change_type, quantity_change, new_available, logged_by, notes) VALUES (?,?,?,?,?,?)")
           ->execute([$id, 'restock', $qty, $newAvail, $user['id'], $notes ?: 'Manual restock']);

        jsonResponse(true, "$qty units added to {$eq['name']}. New total: $newTotal.");

    default:
        jsonResponse(false, 'Unknown action.');
}
