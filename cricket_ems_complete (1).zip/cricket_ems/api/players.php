<?php
// api/players.php — Players Management API
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
$user = requireLogin('admin');
verifyCsrf();

$db     = getDB();
$action = $_POST['action'] ?? '';

switch ($action) {

    // ── ADD PLAYER ────────────────────────────────────────────
    case 'add_player':
        $name     = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $phone    = trim($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($name))     jsonResponse(false, 'Name is required.');
        if (empty($username)) jsonResponse(false, 'Username is required.');
        if (empty($email))    jsonResponse(false, 'Email is required.');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonResponse(false, 'Invalid email address.');
        if (strlen($password) < 6) jsonResponse(false, 'Password must be at least 6 characters.');

        // Check duplicates
        $chk = $db->prepare("SELECT id FROM users WHERE username=? OR email=?");
        $chk->execute([$username, $email]);
        if ($chk->fetch()) jsonResponse(false, 'Username or email already exists.');

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $db->prepare("INSERT INTO users (name, username, email, phone, password, role) VALUES (?,?,?,?,?,'player')")
           ->execute([$name, $username, $email, $phone, $hash]);

        jsonResponse(true, "Player '$name' added successfully.");

    // ── DELETE PLAYER ─────────────────────────────────────────
    case 'delete':
        $id = (int)($_POST['id'] ?? 0);

        // Prevent deleting yourself or admins
        if ($id === $user['id']) jsonResponse(false, 'Cannot delete your own account.');

        $stmt = $db->prepare("SELECT role FROM users WHERE id=?");
        $stmt->execute([$id]);
        $target = $stmt->fetch();
        if (!$target) jsonResponse(false, 'User not found.');
        if ($target['role'] === 'admin') jsonResponse(false, 'Cannot delete admin accounts.');

        // Soft delete
        $db->prepare("UPDATE users SET is_active=0 WHERE id=?")->execute([$id]);

        jsonResponse(true, 'Player removed successfully.');

    default:
        jsonResponse(false, 'Unknown action.');
}
