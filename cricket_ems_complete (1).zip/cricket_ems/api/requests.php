<?php
// api/requests.php — Equipment Request API
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
$user = requireLogin();
verifyCsrf();

$db     = getDB();
$action = $_POST['action'] ?? '';

switch ($action) {

    // ── PLAYER SUBMITS REQUEST ────────────────────────────────
    case 'player_request':
        if ($user['role'] !== 'player') jsonResponse(false, 'Only players can submit requests.');

        $equipId  = (int)($_POST['equipment_id'] ?? 0);
        $quantity = max(1, (int)($_POST['quantity'] ?? 1));
        $notes    = trim($_POST['notes'] ?? '');

        $stmt = $db->prepare("SELECT * FROM equipment WHERE id=? AND is_active=1");
        $stmt->execute([$equipId]);
        $eq = $stmt->fetch();
        if (!$eq) jsonResponse(false, 'Equipment not found.');
        if ($eq['available_units'] < $quantity) jsonResponse(false, "Only {$eq['available_units']} unit(s) available.");

        // Check for duplicate pending
        $dup = $db->prepare("SELECT id FROM equipment_requests WHERE user_id=? AND equipment_id=? AND status='pending' LIMIT 1");
        $dup->execute([$user['id'], $equipId]);
        if ($dup->fetch()) jsonResponse(false, 'You already have a pending request for this equipment.');

        $db->prepare("INSERT INTO equipment_requests (user_id, equipment_id, quantity, status, request_date, notes) VALUES (?,?,?,'pending',CURDATE(),?)")
           ->execute([$user['id'], $equipId, $quantity, $notes]);

        jsonResponse(true, 'Request submitted! Awaiting admin approval.');

    // ── ADMIN APPROVES ────────────────────────────────────────
    case 'approve':
        if ($user['role'] !== 'admin') jsonResponse(false, 'Unauthorized.');

        $id = (int)($_POST['id'] ?? 0);
        $stmt = $db->prepare("SELECT r.*, e.available_units, e.name as equip_name FROM equipment_requests r JOIN equipment e ON r.equipment_id=e.id WHERE r.id=? AND r.status='pending'");
        $stmt->execute([$id]);
        $req = $stmt->fetch();
        if (!$req) jsonResponse(false, 'Request not found or not pending.');
        if ($req['available_units'] < $req['quantity']) jsonResponse(false, "Insufficient stock. Only {$req['available_units']} unit(s) available.");

        $dueDate = date('Y-m-d', strtotime('+14 days'));

        $db->prepare("UPDATE equipment_requests SET status='approved', issue_date=CURDATE(), due_date=?, admin_id=? WHERE id=?")
           ->execute([$dueDate, $user['id'], $id]);
        $db->prepare("UPDATE equipment SET available_units = available_units - ? WHERE id=?")
           ->execute([$req['quantity'], $req['equipment_id']]);

        // Log
        $newAvail = $req['available_units'] - $req['quantity'];
        $db->prepare("INSERT INTO stock_log (equipment_id, change_type, quantity_change, new_available, reference_id, logged_by, notes) VALUES (?,?,?,?,?,?,?)")
           ->execute([$req['equipment_id'], 'issue', -$req['quantity'], $newAvail, $id, $user['id'], "Issued to user #{$req['user_id']}"]);

        jsonResponse(true, "Request approved and equipment issued. Due: " . date('d M Y', strtotime($dueDate)));

    // ── ADMIN REJECTS ─────────────────────────────────────────
    case 'reject':
        if ($user['role'] !== 'admin') jsonResponse(false, 'Unauthorized.');

        $id         = (int)($_POST['id'] ?? 0);
        $adminNotes = trim($_POST['admin_notes'] ?? '');

        $stmt = $db->prepare("SELECT id FROM equipment_requests WHERE id=? AND status='pending'");
        $stmt->execute([$id]);
        if (!$stmt->fetch()) jsonResponse(false, 'Request not found or not pending.');

        $db->prepare("UPDATE equipment_requests SET status='rejected', admin_id=?, admin_notes=? WHERE id=?")
           ->execute([$user['id'], $adminNotes, $id]);

        jsonResponse(true, 'Request rejected.');

    // ── RETURN EQUIPMENT ──────────────────────────────────────
    case 'return':
        if ($user['role'] !== 'admin') jsonResponse(false, 'Only admin can record returns.');

        $id = (int)($_POST['id'] ?? 0);
        $stmt = $db->prepare("SELECT r.*, e.available_units FROM equipment_requests r JOIN equipment e ON r.equipment_id=e.id WHERE r.id=? AND r.status='approved'");
        $stmt->execute([$id]);
        $req = $stmt->fetch();
        if (!$req) jsonResponse(false, 'Active issue not found.');

        $db->prepare("UPDATE equipment_requests SET status='returned', return_date=CURDATE() WHERE id=?")
           ->execute([$id]);
        $db->prepare("UPDATE equipment SET available_units = available_units + ? WHERE id=?")
           ->execute([$req['quantity'], $req['equipment_id']]);

        $newAvail = $req['available_units'] + $req['quantity'];
        $db->prepare("INSERT INTO stock_log (equipment_id, change_type, quantity_change, new_available, reference_id, logged_by, notes) VALUES (?,?,?,?,?,?,?)")
           ->execute([$req['equipment_id'], 'return', $req['quantity'], $newAvail, $id, $user['id'], "Returned by user #{$req['user_id']}"]);

        jsonResponse(true, 'Equipment returned and stock updated.');

    // ── DIRECT ISSUE (ADMIN) ──────────────────────────────────
    case 'direct_issue':
        if ($user['role'] !== 'admin') jsonResponse(false, 'Unauthorized.');

        $userId   = (int)($_POST['user_id'] ?? 0);
        $equipId  = (int)($_POST['equipment_id'] ?? 0);
        $quantity = max(1, (int)($_POST['quantity'] ?? 1));
        $dueDate  = $_POST['due_date'] ?? date('Y-m-d', strtotime('+14 days'));
        $notes    = trim($_POST['notes'] ?? '');

        $stmt = $db->prepare("SELECT * FROM equipment WHERE id=? AND is_active=1");
        $stmt->execute([$equipId]);
        $eq = $stmt->fetch();
        if (!$eq) jsonResponse(false, 'Equipment not found.');
        if ($eq['available_units'] < $quantity) jsonResponse(false, "Only {$eq['available_units']} units available.");

        $uStmt = $db->prepare("SELECT id FROM users WHERE id=? AND role='player'");
        $uStmt->execute([$userId]);
        if (!$uStmt->fetch()) jsonResponse(false, 'Player not found.');

        $db->prepare("INSERT INTO equipment_requests (user_id, equipment_id, quantity, status, request_date, issue_date, due_date, admin_id, notes) VALUES (?,?,?,'approved',CURDATE(),CURDATE(),?,?,?)")
           ->execute([$userId, $equipId, $quantity, $dueDate, $user['id'], $notes]);
        $reqId = $db->lastInsertId();

        $db->prepare("UPDATE equipment SET available_units = available_units - ? WHERE id=?")
           ->execute([$quantity, $equipId]);

        $newAvail = $eq['available_units'] - $quantity;
        $db->prepare("INSERT INTO stock_log (equipment_id, change_type, quantity_change, new_available, reference_id, logged_by, notes) VALUES (?,?,?,?,?,?,?)")
           ->execute([$equipId, 'issue', -$quantity, $newAvail, $reqId, $user['id'], "Direct issue to user #$userId"]);

        jsonResponse(true, 'Equipment issued successfully!');

    // ── FORM DATA FOR DIRECT ISSUE ────────────────────────────
    case 'get_issue_form_data':
        if ($user['role'] !== 'admin') jsonResponse(false, 'Unauthorized.');

        $players   = $db->query("SELECT id, name, username FROM users WHERE role='player' AND is_active=1 ORDER BY name")->fetchAll();
        $equipment = $db->query("SELECT id, name, emoji, available_units FROM equipment WHERE available_units > 0 AND is_active=1 ORDER BY name")->fetchAll();

        jsonResponse(true, 'OK', ['players' => $players, 'equipment' => $equipment]);

    default:
        jsonResponse(false, 'Unknown action.');
}
