-- ============================================================
-- CricketVault Equipment Management System - Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS cricket_ems CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cricket_ems;

-- ── USERS TABLE ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','player') NOT NULL DEFAULT 'player',
    phone VARCHAR(20),
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── EQUIPMENT TABLE ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS equipment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category ENUM('Batting','Fielding','Safety','General','Training','Bowling') NOT NULL,
    emoji VARCHAR(10) DEFAULT '🏏',
    description TEXT,
    total_units INT NOT NULL DEFAULT 0,
    available_units INT NOT NULL DEFAULT 0,
    damaged_units INT NOT NULL DEFAULT 0,
    min_stock_level INT NOT NULL DEFAULT 3,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── EQUIPMENT REQUESTS TABLE ─────────────────────────────────
CREATE TABLE IF NOT EXISTS equipment_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    equipment_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    status ENUM('pending','approved','rejected','returned','cancelled') DEFAULT 'pending',
    request_date DATE NOT NULL,
    issue_date DATE,
    due_date DATE,
    return_date DATE,
    admin_id INT,
    notes TEXT,
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ── DAMAGE LOG TABLE ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS damage_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipment_id INT NOT NULL,
    quantity INT NOT NULL,
    action ENUM('damaged','repaired') NOT NULL,
    reason TEXT,
    logged_by INT NOT NULL,
    logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE,
    FOREIGN KEY (logged_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ── STOCK LOG TABLE ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stock_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipment_id INT NOT NULL,
    change_type ENUM('restock','issue','return','damage','repair') NOT NULL,
    quantity_change INT NOT NULL,
    new_available INT NOT NULL,
    reference_id INT,
    logged_by INT,
    notes TEXT,
    logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE
);

-- ── SEED: ADMIN USER ─────────────────────────────────────────
INSERT INTO users (name, username, email, password, role) VALUES
('Super Admin', 'admin', 'admin@cricketvault.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Rohit Sharma', 'rohit', 'rohit@cricket.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'player'),
('Virat Kohli', 'virat', 'virat@cricket.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'player'),
('MS Dhoni', 'dhoni', 'dhoni@cricket.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'player'),
('Jasprit Bumrah', 'bumrah', 'bumrah@cricket.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'player');
-- Default password for all: "password"

-- ── SEED: EQUIPMENT ──────────────────────────────────────────
INSERT INTO equipment (name, category, emoji, description, total_units, available_units, damaged_units, min_stock_level) VALUES
('Cricket Bat', 'Batting', '🏏', 'Grade 1 English Willow bat, full size', 20, 14, 2, 5),
('Batting Helmet', 'Safety', '⛑️', 'Steel grille helmet with neck guard', 15, 10, 1, 3),
('Batting Gloves', 'Batting', '🧤', 'Padded batting gloves pair', 30, 20, 3, 5),
('Leg Pads', 'Safety', '🦺', 'Full length batting pads, adult size', 25, 17, 0, 4),
('Cricket Ball', 'General', '⚾', 'Dukes red leather cricket ball', 50, 35, 5, 10),
('Wicket Keeping Gloves', 'Fielding', '🥊', 'Professional WK gloves with padding', 10, 6, 1, 2),
('Stumps Set', 'General', '🎯', 'Full set of 3 stumps and 2 bails', 8, 5, 0, 2),
('Thigh Guard', 'Safety', '🛡️', 'Foam padded thigh protection guard', 20, 6, 2, 5),
('Abdominal Guard', 'Safety', '🔒', 'Hard shell abdominal protector', 15, 11, 0, 3),
('Bowling Machine', 'Training', '🤖', 'Automated oscillating bowling machine', 2, 1, 0, 1),
('Fielding Cones', 'Training', '🔺', 'Set of 20 marker cones for drills', 12, 9, 0, 3),
('Cricket Bag', 'General', '🎒', 'Large wheeled cricket kit bag', 18, 12, 1, 4);

-- ── SEED: SAMPLE REQUESTS ────────────────────────────────────
INSERT INTO equipment_requests (user_id, equipment_id, quantity, status, request_date, issue_date, due_date, return_date, admin_id, notes) VALUES
(2, 1, 1, 'approved', CURDATE() - INTERVAL 5 DAY, CURDATE() - INTERVAL 4 DAY, CURDATE() + INTERVAL 10 DAY, NULL, 1, 'For practice match'),
(3, 3, 2, 'pending', CURDATE() - INTERVAL 1 DAY, NULL, NULL, NULL, NULL, 'Tournament use'),
(4, 2, 1, 'returned', CURDATE() - INTERVAL 15 DAY, CURDATE() - INTERVAL 14 DAY, CURDATE() - INTERVAL 5 DAY, CURDATE() - INTERVAL 6 DAY, 1, 'Needed for practice'),
(2, 5, 3, 'approved', CURDATE() - INTERVAL 3 DAY, CURDATE() - INTERVAL 2 DAY, CURDATE() + INTERVAL 12 DAY, NULL, 1, 'Match balls'),
(3, 7, 1, 'pending', CURDATE(), NULL, NULL, NULL, NULL, 'Training session'),
(4, 4, 2, 'rejected', CURDATE() - INTERVAL 2 DAY, NULL, NULL, NULL, 1, 'Already has pads assigned'),
(5, 6, 1, 'approved', CURDATE() - INTERVAL 7 DAY, CURDATE() - INTERVAL 6 DAY, CURDATE() + INTERVAL 7 DAY, NULL, 1, 'WK practice');
