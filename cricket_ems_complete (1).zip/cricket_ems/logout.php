<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';
session_unset();
session_destroy();
redirect(SITE_URL . '/index.php');
