<?php
session_start();
require_once 'includes/db.php';

$job_id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$job_id) {
    header("Location: jobs.php");
    exit();
}

$stmt = $pdo->prepare("SELECT j.*, u.name as employer_name, u.email as employer_email 
                       FROM jobs j 
                       JOIN users u ON j.employer_id = u.id 
                       WHERE j.id = ?");
$stmt->execute([$job_id]);
$job = $stmt->fetch();

if (!$job) {
    header("Location: jobs.php");
    exit();
}

// Check if user has already applied
$has_applied = false;
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'user') {
    $stmt_check = $pdo->prepare("SELECT id FROM applications WHERE job_id = ? AND user_id = ?");
    $stmt_check->execute([$job_id, $_SESSION['user_id']]);
    if ($stmt_check->fetch()) {
        $has_applied = true;
    }
}

include 'includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="card shadow-sm border-0 rounded-3 mb-4">
                <div class="card-body p-4 p-md-5">
                    <div class="d-flex justify-content-between align-items-start mb-4">
                        <div>
                            <h2 class="fw-bold text-dark mb-2"><?php echo htmlspecialchars($job['title']); ?></h2>
                            <h5 class="text-primary mb-0"><i class="bi bi-building"></i> <?php echo htmlspecialchars($job['employer_name']); ?></h5>
                        </div>
                    </div>
                    
                    <div class="d-flex flex-wrap gap-3 mb-4 py-3 border-top border-bottom">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-geo-alt fs-4 text-muted me-2"></i>
                            <div>
                                <small class="text-muted d-block lh-1">Location</small>
                                <span class="fw-medium"><?php echo htmlspecialchars($job['location']); ?></span>
                            </div>
                        </div>
                        <div class="d-flex align-items-center ms-md-4">
                            <i class="bi bi-briefcase fs-4 text-muted me-2"></i>
                            <div>
                                <small class="text-muted d-block lh-1">Job Type</small>
                                <span class="fw-medium"><?php echo htmlspecialchars(ucwords(str_replace('-', ' ', $job['job_type']))); ?></span>
                            </div>
                        </div>
                        <div class="d-flex align-items-center ms-md-4">
                            <i class="bi bi-cash fs-4 text-muted me-2"></i>
                            <div>
                                <small class="text-muted d-block lh-1">Salary</small>
                                <span class="fw-medium text-success"><?php echo !empty($job['salary']) ? htmlspecialchars($job['salary']) : 'Not Disclosed'; ?></span>
                            </div>
                        </div>
                        <div class="d-flex align-items-center ms-md-4">
                            <i class="bi bi-calendar3 fs-4 text-muted me-2"></i>
                            <div>
                                <small class="text-muted d-block lh-1">Posted On</small>
                                <span class="fw-medium"><?php echo date('M d, Y', strtotime($job['posted_date'])); ?></span>
                            </div>
                        </div>
                    </div>

                    <h4 class="fw-bold mb-3">Job Description</h4>
                    <div class="text-muted lh-lg mb-5" style="white-space: pre-wrap;"><?php echo htmlspecialchars($job['description']); ?></div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <div class="card shadow-sm border-0 rounded-3 sticky-top" style="top: 100px;">
                <div class="card-body p-4 text-center">
                    <h5 class="fw-bold mb-4">Interested in this job?</h5>
                    
                    <?php if (!isset($_SESSION['user_id'])): ?>
                        <div class="alert alert-info py-2 small mb-4">Please login to apply for this job.</div>
                        <a href="login.php" class="btn btn-primary w-100 mb-2">Login to Apply</a>
                        <a href="register.php" class="btn btn-outline-primary w-100">Create an Account</a>
                    <?php elseif ($_SESSION['role'] === 'user'): ?>
                        <?php if ($has_applied): ?>
                            <button class="btn btn-success w-100 disabled py-2 mb-3">
                                <i class="bi bi-check-circle me-2"></i> Already Applied
                            </button>
                            <a href="user/applied_jobs.php" class="btn btn-outline-primary w-100">View Application Status</a>
                        <?php else: ?>
                            <a href="apply_job.php?id=<?php echo $job['id']; ?>" class="btn btn-primary w-100 py-3 fw-bold shadow-sm">
                                Apply Now <i class="bi bi-arrow-right ms-2"></i>
                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="alert alert-warning py-2 small mb-0">You are logged in as an <?php echo $_SESSION['role']; ?>. Only Job Seekers can apply.</div>
                    <?php endif; ?>
                    
                    <hr class="my-4">
                    <p class="small text-muted mb-0">Share this job:</p>
                    <div class="d-flex justify-content-center gap-2 mt-2">
                        <button class="btn btn-outline-secondary btn-sm rounded-circle shadow-sm" style="width: 35px; height: 35px;"><i class="bi bi-twitter"></i></button>
                        <button class="btn btn-outline-secondary btn-sm rounded-circle shadow-sm" style="width: 35px; height: 35px;"><i class="bi bi-linkedin"></i></button>
                        <button class="btn btn-outline-secondary btn-sm rounded-circle shadow-sm" style="width: 35px; height: 35px;"><i class="bi bi-facebook"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
