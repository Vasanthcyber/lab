<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user profile completion status
$stmt = $pdo->prepare("SELECT * FROM profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();
$profile_complete = !empty($profile['phone']) && !empty($profile['skills']) && !empty($profile['education']);

// Get resume count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM resumes WHERE user_id = ?");
$stmt->execute([$user_id]);
$resume_count = $stmt->fetchColumn();

// Get application stats
$stmt = $pdo->prepare("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'reviewed' THEN 1 ELSE 0 END) as reviewed,
    SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted,
    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
    FROM applications WHERE user_id = ?");
$stmt->execute([$user_id]);
$stats = $stmt->fetch();

// Get recent applications
$stmt = $pdo->prepare("SELECT a.*, j.title, u.name as employer_name 
                       FROM applications a 
                       JOIN jobs j ON a.job_id = j.id 
                       JOIN users u ON j.employer_id = u.id 
                       WHERE a.user_id = ? 
                       ORDER BY a.applied_date DESC LIMIT 5");
$stmt->execute([$user_id]);
$recent_applications = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-primary text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-primary rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-person-fill fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h5>
                        <small class="text-white-50">Job Seeker</small>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="profile.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-person me-2"></i> My Profile</a>
                        <a href="applied_jobs.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Applied Jobs</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <h3 class="fw-bold mb-4">Dashboard Overview</h3>

            <?php if (!$profile_complete || $resume_count == 0): ?>
                <div class="alert alert-warning shadow-sm border-0 mb-4 d-flex align-items-center">
                    <i class="bi bi-exclamation-triangle fs-3 me-3"></i>
                    <div>
                        <h5 class="alert-heading mb-1">Complete your profile!</h5>
                        <p class="mb-0">You need to <a href="edit_profile.php" class="alert-link">complete your profile details</a> and <a href="profile.php" class="alert-link">upload a resume</a> before applying for jobs.</p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Stats Boxes -->
            <div class="row g-4 mb-4">
                <div class="col-sm-6 col-lg-3">
                    <div class="card shadow-sm border-0 bg-primary text-white h-100">
                        <div class="card-body text-center p-4">
                            <h1 class="display-4 fw-bold mb-0"><?php echo $stats['total'] ?? 0; ?></h1>
                            <p class="mb-0">Total Applications</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="card shadow-sm border-0 bg-warning text-dark h-100">
                        <div class="card-body text-center p-4">
                            <h1 class="display-4 fw-bold mb-0"><?php echo $stats['pending'] ?? 0; ?></h1>
                            <p class="mb-0">Pending</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="card shadow-sm border-0 bg-info text-white h-100">
                        <div class="card-body text-center p-4">
                            <h1 class="display-4 fw-bold mb-0"><?php echo $stats['reviewed'] ?? 0; ?></h1>
                            <p class="mb-0">Reviewed</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="card shadow-sm border-0 bg-success text-white h-100">
                        <div class="card-body text-center p-4">
                            <h1 class="display-4 fw-bold mb-0"><?php echo ($stats['accepted'] ?? 0) + ($stats['rejected'] ?? 0); ?></h1>
                            <p class="mb-0">Decisions</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Applications -->
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white border-0 p-4 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0">Recent Applications</h5>
                    <a href="applied_jobs.php" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-muted">
                                <tr>
                                    <th class="px-4 py-3">Job Title</th>
                                    <th class="py-3">Company</th>
                                    <th class="py-3">Applied Date</th>
                                    <th class="px-4 py-3">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recent_applications)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-5 text-muted">You haven't applied to any jobs yet. <a href="../jobs.php">Browse Jobs</a></td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($recent_applications as $app): ?>
                                        <tr>
                                            <td class="px-4 py-3">
                                                <a href="../job_details.php?id=<?php echo $app['job_id']; ?>" class="text-decoration-none fw-medium text-dark">
                                                    <?php echo htmlspecialchars($app['title']); ?>
                                                </a>
                                            </td>
                                            <td class="py-3 text-muted"><?php echo htmlspecialchars($app['employer_name']); ?></td>
                                            <td class="py-3 text-muted"><?php echo date('M d, Y', strtotime($app['applied_date'])); ?></td>
                                            <td class="px-4 py-3 text-capitalize">
                                                <span class="badge badge-status-<?php echo $app['status']; ?> py-2 px-3 rounded-pill">
                                                    <?php echo $app['status']; ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
