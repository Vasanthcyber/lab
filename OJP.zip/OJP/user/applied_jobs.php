<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch all applications
$stmt = $pdo->prepare("SELECT a.*, j.title, j.location, j.job_type, u.name as employer_name 
                       FROM applications a 
                       JOIN jobs j ON a.job_id = j.id 
                       JOIN users u ON j.employer_id = u.id 
                       WHERE a.user_id = ? 
                       ORDER BY a.applied_date DESC");
$stmt->execute([$user_id]);
$applications = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-primary text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-primary rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-person-fill fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h5>
                        <small class="text-white-50">Job Seeker</small>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="profile.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-person me-2"></i> My Profile</a>
                        <a href="applied_jobs.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Applied Jobs</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <h3 class="fw-bold mb-4">My Job Applications</h3>

            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <?php if (empty($applications)): ?>
                        <div class="p-5 text-center text-muted">
                            <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                <i class="bi bi-journal-x fs-1"></i>
                            </div>
                            <h4 class="fw-bold mb-2">No Applications Yet</h4>
                            <p class="mb-4">You haven't applied to any jobs yet. Start exploring opportunities!</p>
                            <a href="../jobs.php" class="btn btn-primary px-4"><i class="bi bi-search me-2"></i>Browse Jobs</a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light text-muted">
                                    <tr>
                                        <th class="px-4 py-3 border-0">Job Title</th>
                                        <th class="py-3 border-0">Company</th>
                                        <th class="py-3 border-0">Applied On</th>
                                        <th class="px-4 py-3 border-0">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($applications as $app): ?>
                                        <tr>
                                            <td class="px-4 py-4">
                                                <a href="../job_details.php?id=<?php echo $app['job_id']; ?>" class="text-decoration-none fw-bold text-dark d-block mb-1">
                                                    <?php echo htmlspecialchars($app['title']); ?>
                                                </a>
                                                <small class="text-muted"><i class="bi bi-geo-alt me-1"></i> <?php echo htmlspecialchars($app['location']); ?> &middot; <?php echo htmlspecialchars(ucwords(str_replace('-', ' ', $app['job_type']))); ?></small>
                                            </td>
                                            <td class="py-4 text-dark fw-medium">
                                                <i class="bi bi-building text-muted me-2"></i><?php echo htmlspecialchars($app['employer_name']); ?>
                                            </td>
                                            <td class="py-4 text-muted">
                                                <?php echo date('M d, Y', strtotime($app['applied_date'])); ?>
                                            </td>
                                            <td class="px-4 py-4 text-capitalize">
                                                <span class="badge badge-status-<?php echo $app['status']; ?> py-2 px-3 rounded text-uppercase" style="font-size: 0.75rem; letter-spacing: 0.5px;">
                                                    <?php 
                                                        if ($app['status'] == 'pending') echo '<i class="bi bi-clock me-1"></i> Pending';
                                                        elseif ($app['status'] == 'reviewed') echo '<i class="bi bi-eye me-1"></i> Reviewed';
                                                        elseif ($app['status'] == 'accepted') echo '<i class="bi bi-check-circle me-1"></i> Accepted';
                                                        elseif ($app['status'] == 'rejected') echo '<i class="bi bi-x-circle me-1"></i> Rejected';
                                                    ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
