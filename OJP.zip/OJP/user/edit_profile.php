<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $education = trim($_POST['education'] ?? '');
    $experience = trim($_POST['experience'] ?? '');

    if (empty($name)) {
        $error = "Name cannot be empty.";
    } else {
        try {
            $pdo->beginTransaction();

            // Update users table
            $stmt = $pdo->prepare("UPDATE users SET name = ? WHERE id = ?");
            $stmt->execute([$name, $user_id]);
            $_SESSION['user_name'] = $name; // Update session name
            
            // Check if profile exists
            $stmt = $pdo->prepare("SELECT id FROM profiles WHERE user_id = ?");
            $stmt->execute([$user_id]);
            if ($stmt->fetch()) {
                // Update profile
                $stmt = $pdo->prepare("UPDATE profiles SET phone = ?, skills = ?, education = ?, experience = ? WHERE user_id = ?");
                $stmt->execute([$phone, $skills, $education, $experience, $user_id]);
            } else {
                // Insert profile (fallback if not created during registration)
                $stmt = $pdo->prepare("INSERT INTO profiles (user_id, phone, skills, education, experience) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $phone, $skills, $education, $experience]);
            }

            $pdo->commit();
            $success = "Profile updated successfully!";
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Failed to update profile. Please try again.";
        }
    }
}

// Fetch current data
$stmt = $pdo->prepare("SELECT u.name, u.email, p.* FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.id = ?");
$stmt->execute([$user_id]);
$user_data = $stmt->fetch();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-primary text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-primary rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-person-fill fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h5>
                        <small class="text-white-50">Job Seeker</small>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="profile.php" class="list-group-item list-group-item-action border-0 px-4 py-3 bg-light"><i class="bi bi-person me-2"></i> My Profile</a>
                        <a href="applied_jobs.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Applied Jobs</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white border-bottom-0 p-4 pb-0 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0">Edit Profile</h5>
                    <a href="profile.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i> Back to Profile</a>
                </div>
                <div class="card-body p-4">
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($success); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <h6 class="text-muted mb-3 fw-bold border-bottom pb-2">Basic Information</h6>
                        <div class="row mb-4">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($user_data['name']); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email Address (Cannot change)</label>
                                <input type="email" class="form-control bg-light" readonly value="<?php echo htmlspecialchars($user_data['email']); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user_data['phone'] ?? ''); ?>">
                            </div>
                        </div>

                        <h6 class="text-muted mb-3 fw-bold border-bottom pb-2">Professional Details</h6>
                        <div class="mb-4">
                            <label class="form-label">Key Skills (Comma separated)</label>
                            <textarea name="skills" class="form-control" rows="3" placeholder="e.g. PHP, JavaScript, MySQL, Communication"><?php echo htmlspecialchars($user_data['skills'] ?? ''); ?></textarea>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Education Details</label>
                            <textarea name="education" class="form-control" rows="4" placeholder="Degree, Institution, Year..."><?php echo htmlspecialchars($user_data['education'] ?? ''); ?></textarea>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Work Experience</label>
                            <textarea name="experience" class="form-control" rows="4" placeholder="Job Title, Company, Duration, Responsibilities..."><?php echo htmlspecialchars($user_data['experience'] ?? ''); ?></textarea>
                        </div>

                        <div class="text-end">
                            <a href="profile.php" class="btn btn-light border px-4 me-2">Cancel</a>
                            <button type="submit" class="btn btn-primary px-4"><i class="bi bi-save me-2"></i> Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
