<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle Resume Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['resume'])) {
    $file = $_FILES['resume'];
    
    // Validate file
    $allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    $allowed_exts = ['pdf', 'doc', 'docx'];
    
    $file_info = pathinfo($file['name']);
    $ext = strtolower($file_info['extension'] ?? '');
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = "File upload error.";
    } elseif (!in_array($file['type'], $allowed_types) || !in_array($ext, $allowed_exts)) {
        $error = "Only PDF, DOC, and DOCX files are allowed.";
    } elseif ($file['size'] > 5 * 1024 * 1024) { // 5MB limit
        $error = "File size must be less than 5MB.";
    } else {
        // Create upload directory if it doesn't exist
        $upload_dir = '../uploads/resumes/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $new_filename = uniqid('resume_') . '_' . $user_id . '.' . $ext;
        $destination = $upload_dir . $new_filename;
        
        if (move_uploaded_file($file['tmp_name'], $destination)) {
            // Save to database
            $db_path = 'uploads/resumes/' . $new_filename;
            $stmt = $pdo->prepare("INSERT INTO resumes (user_id, file_path) VALUES (?, ?)");
            $stmt->execute([$user_id, $db_path]);
            $success = "Resume uploaded successfully!";
        } else {
            $error = "Failed to move uploaded file.";
        }
    }
}

// Handle Resume Deletion
if (isset($_GET['delete_resume']) && is_numeric($_GET['delete_resume'])) {
    $resume_id = (int)$_GET['delete_resume'];
    
    // Check if resume belongs to user
    $stmt = $pdo->prepare("SELECT file_path FROM resumes WHERE id = ? AND user_id = ?");
    $stmt->execute([$resume_id, $user_id]);
    $resume = $stmt->fetch();
    
    if ($resume) {
        // Check if resume is used in any application
        $stmt_check = $pdo->prepare("SELECT id FROM applications WHERE resume_id = ?");
        $stmt_check->execute([$resume_id]);
        if ($stmt_check->fetch()) {
            $error = "Cannot delete resume. It is being used in one or more job applications.";
        } else {
            // Delete file
            $file_to_delete = '../' . $resume['file_path'];
            if (file_exists($file_to_delete)) {
                unlink($file_to_delete);
            }
            // Delete from database
            $stmt = $pdo->prepare("DELETE FROM resumes WHERE id = ?");
            $stmt->execute([$resume_id]);
            $success = "Resume deleted successfully!";
        }
    }
}

// Fetch user data
$stmt = $pdo->prepare("SELECT u.name, u.email, p.* FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.id = ?");
$stmt->execute([$user_id]);
$user_data = $stmt->fetch();

// Fetch user resumes
$stmt = $pdo->prepare("SELECT * FROM resumes WHERE user_id = ? ORDER BY uploaded_at DESC");
$stmt->execute([$user_id]);
$resumes = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-primary text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-primary rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-person-fill fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h5>
                        <small class="text-white-50">Job Seeker</small>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="profile.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-person me-2"></i> My Profile</a>
                        <a href="applied_jobs.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Applied Jobs</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                    <?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Profile Details -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-bottom-0 p-4 pb-0 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0">Personal Profile</h5>
                    <a href="edit_profile.php" class="btn btn-outline-primary btn-sm"><i class="bi bi-pencil me-1"></i> Edit Profile</a>
                </div>
                <div class="card-body p-4">
                    <div class="row mb-4">
                        <div class="col-sm-3 text-muted">Full Name</div>
                        <div class="col-sm-9 fw-medium"><?php echo htmlspecialchars($user_data['name']); ?></div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-sm-3 text-muted">Email</div>
                        <div class="col-sm-9 fw-medium"><?php echo htmlspecialchars($user_data['email']); ?></div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-sm-3 text-muted">Phone Number</div>
                        <div class="col-sm-9">
                            <?php echo !empty($user_data['phone']) ? htmlspecialchars($user_data['phone']) : '<span class="text-muted fst-italic">Not provided</span>'; ?>
                        </div>
                    </div>
                    <hr class="text-muted">
                    <div class="row mb-4">
                        <div class="col-12 text-muted mb-2">Skills</div>
                        <div class="col-12" style="white-space: pre-wrap;"><?php echo !empty($user_data['skills']) ? htmlspecialchars($user_data['skills']) : '<span class="text-muted fst-italic">No skills added yet.</span>'; ?></div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-12 text-muted mb-2">Education</div>
                        <div class="col-12" style="white-space: pre-wrap;"><?php echo !empty($user_data['education']) ? htmlspecialchars($user_data['education']) : '<span class="text-muted fst-italic">No education details added yet.</span>'; ?></div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-muted mb-2">Experience</div>
                        <div class="col-12" style="white-space: pre-wrap;"><?php echo !empty($user_data['experience']) ? htmlspecialchars($user_data['experience']) : '<span class="text-muted fst-italic">No experience details added yet.</span>'; ?></div>
                    </div>
                </div>
            </div>

            <!-- Resume Management -->
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white border-bottom-0 p-4 pb-0">
                    <h5 class="fw-bold mb-0">Manage Resumes</h5>
                    <p class="text-muted small mt-1 mb-0">Upload your resume to apply for jobs (PDF, DOC, DOCX up to 5MB).</p>
                </div>
                <div class="card-body p-4">
                    <!-- Upload Form -->
                    <form method="POST" action="" enctype="multipart/form-data" class="mb-5 bg-light p-4 rounded-3 border">
                        <div class="row align-items-end">
                            <div class="col-md-9 mb-3 mb-md-0">
                                <label class="form-label fw-medium text-dark">Select Resume File</label>
                                <input class="form-control" type="file" name="resume" accept=".pdf,.doc,.docx" required>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary w-100"><i class="bi bi-upload me-2"></i> Upload</button>
                            </div>
                        </div>
                    </form>

                    <!-- Resumes List -->
                    <h6 class="fw-bold mb-3">Your Uploaded Resumes</h6>
                    <?php if (empty($resumes)): ?>
                        <div class="text-center py-4 bg-light rounded text-muted border border-dashed">
                            <i class="bi bi-file-earmark-x fs-1 d-block mb-2"></i>
                            No resumes uploaded yet.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border">
                                <thead class="bg-light text-muted">
                                    <tr>
                                        <th class="px-3">File Name</th>
                                        <th>Uploaded On</th>
                                        <th class="text-end px-3">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($resumes as $resume): ?>
                                        <?php 
                                            // Get original filename without the uniqid part if possible
                                            $filename = basename($resume['file_path']);
                                            $display_name = preg_replace('/^resume_[^_]+_/', 'Resume_', $filename);
                                        ?>
                                        <tr>
                                            <td class="px-3">
                                                <i class="bi bi-file-earmark-text text-primary me-2"></i>
                                                <a href="../<?php echo htmlspecialchars($resume['file_path']); ?>" target="_blank" class="text-decoration-none">
                                                    <?php echo htmlspecialchars($display_name); ?>
                                                </a>
                                            </td>
                                            <td class="text-muted small"><?php echo date('M d, Y H:i', strtotime($resume['uploaded_at'])); ?></td>
                                            <td class="text-end px-3">
                                                <a href="../<?php echo htmlspecialchars($resume['file_path']); ?>" target="_blank" class="btn btn-sm btn-outline-secondary me-1" title="View"><i class="bi bi-eye"></i></a>
                                                <a href="profile.php?delete_resume=<?php echo $resume['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this resume?');" title="Delete"><i class="bi bi-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
