<?php
require_once 'includes/db.php';
include 'includes/header.php';

// Fetch the latest 6 jobs
$stmt = $pdo->query("SELECT j.*, u.name as employer_name FROM jobs j JOIN users u ON j.employer_id = u.id ORDER BY posted_date DESC LIMIT 6");
$latest_jobs = $stmt->fetchAll();
?>

<!-- Hero Section -->
<section class="hero-section text-white">
    <div class="container py-5">
        <h1 class="display-4 fw-bold mb-4">Find Your Dream Job Today</h1>
        <p class="lead mb-5">Browse thousands of job openings from top companies and start your career journey.</p>
        
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="jobs.php" method="GET" class="d-flex bg-white p-2 rounded shadow-sm">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-0"><i class="bi bi-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control border-0 shadow-none" placeholder="Job title, keywords, or company...">
                    </div>
                    <div class="input-group ms-2">
                        <span class="input-group-text bg-white border-0"><i class="bi bi-geo-alt text-muted"></i></span>
                        <input type="text" name="location" class="form-control border-0 shadow-none" placeholder="City, state, or zip code...">
                    </div>
                    <button type="submit" class="btn btn-primary px-4 ms-2 rounded">Search</button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Latest Jobs Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold m-0">Latest Job Openings</h2>
            <a href="jobs.php" class="btn btn-outline-primary">View All Jobs <i class="bi bi-arrow-right"></i></a>
        </div>
        
        <div class="row g-4">
            <?php if (empty($latest_jobs)): ?>
                <div class="col-12 py-5 text-center">
                    <p class="text-muted">No jobs posted yet. Check back soon!</p>
                </div>
            <?php else: ?>
                <?php foreach ($latest_jobs as $job): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card job-card h-100 rounded-3">
                            <div class="card-body p-4">
                                <div class="d-flex justify-content-between mb-3">
                                    <h5 class="card-title fw-bold mb-0 text-truncate" title="<?php echo htmlspecialchars($job['title']); ?>">
                                        <?php echo htmlspecialchars($job['title']); ?>
                                    </h5>
                                    <span class="badge bg-primary bg-opacity-10 text-primary py-2 px-3 rounded-pill" style="white-space:nowrap">
                                        <?php echo htmlspecialchars(ucwords($job['job_type'])); ?>
                                    </span>
                                </div>
                                <h6 class="card-subtitle mb-3 text-muted">
                                    <i class="bi bi-building me-1"></i> <?php echo htmlspecialchars($job['employer_name']); ?>
                                </h6>
                                <p class="card-text text-muted mb-4 small">
                                    <i class="bi bi-geo-alt me-1"></i> <?php echo htmlspecialchars($job['location']); ?>
                                </p>
                                <div class="d-flex justify-content-between align-items-center mt-auto">
                                    <span class="fw-bold text-success">
                                        <?php echo !empty($job['salary']) ? htmlspecialchars($job['salary']) : 'Salary not disclosed'; ?>
                                    </span>
                                </div>
                            </div>
                            <div class="card-footer bg-white border-top-0 p-4 pt-0">
                                <a href="job_details.php?id=<?php echo $job['id']; ?>" class="btn btn-primary w-100">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5">
    <div class="container py-4">
        <div class="row text-center g-4">
            <div class="col-md-4">
                <div class="p-4">
                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-4" style="width: 80px; height: 80px;">
                        <i class="bi bi-search fs-1"></i>
                    </div>
                    <h4 class="fw-bold">Search Jobs</h4>
                    <p class="text-muted">Easily find jobs based on your skills, preferences, and location with our advanced search.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4">
                    <div class="bg-success bg-opacity-10 text-success rounded-circle d-inline-flex align-items-center justify-content-center mb-4" style="width: 80px; height: 80px;">
                        <i class="bi bi-file-earmark-person fs-1"></i>
                    </div>
                    <h4 class="fw-bold">Upload Resume</h4>
                    <p class="text-muted">Create a profile, upload your resume, and let employers find you for their open roles.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4">
                    <div class="bg-info bg-opacity-10 text-info rounded-circle d-inline-flex align-items-center justify-content-center mb-4" style="width: 80px; height: 80px;">
                        <i class="bi bi-send-check fs-1"></i>
                    </div>
                    <h4 class="fw-bold">Apply Easily</h4>
                    <p class="text-muted">Apply to multiple jobs with just a few clicks and track your application status in real-time.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
