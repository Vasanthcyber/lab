    </main>
    <!-- Main Content Container End -->

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5>JobPortal</h5>
                    <p class="text-muted">Connecting talented professionals with amazing opportunities around the world.</p>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo BASE_URL; ?>/index.php" class="text-muted text-decoration-none">Home</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/jobs.php" class="text-muted text-decoration-none">Browse Jobs</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/register.php" class="text-muted text-decoration-none">Register</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Contact Us</h5>
                    <ul class="list-unstyled text-muted">
                        <li><i class="bi bi-geo-alt me-2"></i> 123 Business Avenue, CA</li>
                        <li><i class="bi bi-envelope me-2"></i> info@jobportal.com</li>
                        <li><i class="bi bi-telephone me-2"></i> +1 234 567 8900</li>
                    </ul>
                </div>
            </div>
            <hr class="border-secondary">
            <div class="text-center text-muted">
                <small>&copy; <?php echo date('Y'); ?> JobPortal. All rights reserved.</small>
            </div>
        </div>
    </footer>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo BASE_URL; ?>/assets/js/script.js"></script>
</body>
</html>
