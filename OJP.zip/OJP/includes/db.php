<?php
$host = "localhost";
$dbname = "job_portal";
$username = "root"; // Default XAMPP username
$password = ""; // Default XAMPP password

try {
    $pdo = new PDO("mysql:host=$host", $username, $password);
    // Ensure the database exists
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname`");
    $pdo->exec("USE `$dbname`");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
