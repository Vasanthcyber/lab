<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$user_role = $_SESSION['role'] ?? null;

// Define BASE_URL dynamically
if (!defined('BASE_URL')) {
    $doc_root = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'], '/'));
    $base_dir = str_replace('\\', '/', dirname(__DIR__));
    $base_url = str_replace($doc_root, '', $base_dir);
    define('BASE_URL', rtrim($base_url, '/'));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Job Portal</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo BASE_URL; ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="<?php echo BASE_URL; ?>/index.php">
                <i class="bi bi-briefcase-fill me-2"></i>JobPortal
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/jobs.php">Find Jobs</a></li>
                    
                    <?php if (!$user_role): ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/login.php">Login</a></li>
                        <li class="nav-item"><a class="btn btn-primary ms-2" href="<?php echo BASE_URL; ?>/register.php">Register</a></li>
                    <?php else: ?>
                        <!-- User Dropdown -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle"></i> Account
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php if ($user_role === 'user'): ?>
                                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/user/dashboard.php">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/user/profile.php">My Profile</a></li>
                                <?php elseif ($user_role === 'employer'): ?>
                                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/employer/dashboard.php">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/employer/post_job.php">Post a Job</a></li>
                                <?php elseif ($user_role === 'admin'): ?>
                                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/admin/dashboard.php">Admin Panel</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>/logout.php">Logout</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content Container Start -->
    <main class="min-vh-100">
