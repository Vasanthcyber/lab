<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$success = '';
$error = '';

// Handle Delete User
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];
    
    // Check if target is not admin
    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$delete_id]);
    $user = $stmt->fetch();
    
    if ($user && $user['role'] !== 'admin') {
        try {
            // Because of ON DELETE CASCADE, deleting a user will also delete their related data
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$delete_id]);
            $success = "User deleted successfully.";
        } catch (PDOException $e) {
            $error = "Failed to delete user. " . $e->getMessage();
        }
    } else {
        $error = "Unauthorized action or user not found.";
    }
}

// Fetch users based on role filter
$role_filter = $_GET['role'] ?? '';
$where = "WHERE role != 'admin'";
$params = [];

if ($role_filter === 'user' || $role_filter === 'employer') {
    $where .= " AND role = ?";
    $params[] = $role_filter;
}

$query = "SELECT id, name, email, role, created_at FROM users $where ORDER BY created_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-danger text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-danger rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-shield-lock fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0">Admin Panel</h5>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="manage_users.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-people me-2"></i> Manage Users</a>
                        <a href="manage_jobs.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Manage Jobs</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <h3 class="fw-bold mb-4">Manage Users</h3>

            <!-- Filters -->
            <div class="card shadow-sm border-0 mb-4 bg-light">
                <div class="card-body p-3">
                    <form method="GET" action="" class="d-flex align-items-center">
                        <label class="fw-bold me-3">Filter by Role:</label>
                        <select name="role" class="form-select w-auto me-3" onchange="this.form.submit()">
                            <option value="">All Users</option>
                            <option value="user" <?php echo $role_filter === 'user' ? 'selected' : ''; ?>>Job Seekers</option>
                            <option value="employer" <?php echo $role_filter === 'employer' ? 'selected' : ''; ?>>Employers</option>
                        </select>
                    </form>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <?php if (empty($users)): ?>
                        <div class="p-5 text-center text-muted">
                            <h5 class="fw-bold text-dark">No Users Found</h5>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light text-muted">
                                    <tr>
                                        <th class="px-4 py-3 border-0">User Details</th>
                                        <th class="py-3 border-0 text-center">Role</th>
                                        <th class="py-3 border-0 text-center">Registered Date</th>
                                        <th class="px-4 py-3 border-0 text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td class="px-4 py-4">
                                                <div class="fw-bold text-dark mb-1">
                                                    <?php echo htmlspecialchars($user['name']); ?>
                                                </div>
                                                <div class="small text-muted"><i class="bi bi-envelope me-1"></i> <?php echo htmlspecialchars($user['email']); ?></div>
                                            </td>
                                            <td class="py-4 text-center text-capitalize">
                                                <span class="badge bg-<?php echo $user['role'] === 'employer' ? 'success' : 'primary'; ?> bg-opacity-10 text-<?php echo $user['role'] === 'employer' ? 'success' : 'primary'; ?> py-1 px-3 rounded-pill">
                                                    <?php echo $user['role']; ?>
                                                </span>
                                            </td>
                                            <td class="py-4 text-center text-muted">
                                                <?php echo date('M d, Y h:i A', strtotime($user['created_at'])); ?>
                                            </td>
                                            <td class="px-4 py-4 text-end">
                                                <a href="?delete=<?php echo $user['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this user? ALL THEIR JOBS, APPLICATIONS, AND DATA WILL BE LOST PERMANENTLY.');" title="Delete User">
                                                    <i class="bi bi-trash"></i> Delete
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
