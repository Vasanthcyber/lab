<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$success = '';
$error = '';

// Handle Job Deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];
    
    try {
        // Because of ON DELETE CASCADE, deleting a job will also delete related applications
        $stmt = $pdo->prepare("DELETE FROM jobs WHERE id = ?");
        $stmt->execute([$delete_id]);
        $success = "Job deleted successfully.";
    } catch (PDOException $e) {
        $error = "Failed to delete job.";
    }
}

// Fetch all jobs
$query = "SELECT j.*, u.name as employer_name, u.email as employer_email,
          COUNT(a.id) as total_applicants
          FROM jobs j 
          JOIN users u ON j.employer_id = u.id 
          LEFT JOIN applications a ON j.id = a.job_id 
          GROUP BY j.id 
          ORDER BY j.posted_date DESC";
$stmt = $pdo->prepare($query);
$stmt->execute();
$jobs = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-danger text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-danger rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-shield-lock fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0">Admin Panel</h5>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="manage_users.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-people me-2"></i> Manage Users</a>
                        <a href="manage_jobs.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Manage Jobs</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <h3 class="fw-bold mb-4">Manage Jobs</h3>

            <div class="alert alert-info py-2 mb-4 d-flex align-items-center">
                <i class="bi bi-info-circle-fill me-2"></i> 
                As an administrator, you can view and delete jobs that violate platform policies.
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <?php if (empty($jobs)): ?>
                        <div class="p-5 text-center text-muted">
                            <h5 class="fw-bold text-dark">No Jobs Found</h5>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light text-muted">
                                    <tr>
                                        <th class="px-4 py-3 border-0">Job Title</th>
                                        <th class="py-3 border-0">Employer Info</th>
                                        <th class="py-3 border-0 text-center">Stats</th>
                                        <th class="px-4 py-3 border-0 text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($jobs as $job): ?>
                                        <tr>
                                            <td class="px-4 py-4 w-25">
                                                <a href="../job_details.php?id=<?php echo $job['id']; ?>" class="fw-bold text-dark text-decoration-none d-block mb-1" target="_blank">
                                                    <?php echo htmlspecialchars($job['title']); ?>
                                                </a>
                                                <span class="badge bg-light text-dark border"><i class="bi bi-calendar3 me-1"></i> <?php echo date('M d, Y', strtotime($job['posted_date'])); ?></span>
                                            </td>
                                            <td class="py-4 w-25">
                                                <div class="fw-medium text-dark"><i class="bi bi-building text-muted me-1"></i> <?php echo htmlspecialchars($job['employer_name']); ?></div>
                                                <div class="small text-muted text-truncate" style="max-width: 150px;" title="<?php echo htmlspecialchars($job['employer_email']); ?>">
                                                    <?php echo htmlspecialchars($job['employer_email']); ?>
                                                </div>
                                            </td>
                                            <td class="py-4 text-center">
                                                <span class="badge bg-primary bg-opacity-10 text-primary py-1 px-2 rounded-pill shadow-sm" title="Total Applicants">
                                                    <i class="bi bi-people me-1"></i> <?php echo $job['total_applicants']; ?>
                                                </span>
                                            </td>
                                            <td class="px-4 py-4 text-end">
                                                <div class="btn-group">
                                                    <a href="../job_details.php?id=<?php echo $job['id']; ?>" class="btn btn-sm btn-outline-primary" target="_blank" title="View Job Page"><i class="bi bi-eye"></i> View</a>
                                                    <a href="?delete=<?php echo $job['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this job listing? It will remove all associated applications.');" title="Delete Job Listing">
                                                        <i class="bi bi-trash"></i> Delete
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
