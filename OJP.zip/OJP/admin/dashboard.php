<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get counts
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'");
$total_job_seekers = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'employer'");
$total_employers = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM jobs");
$total_jobs = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM applications");
$total_applications = $stmt->fetchColumn();

// Get recent users
$stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users WHERE role != 'admin' ORDER BY created_at DESC LIMIT 5");
$recent_users = $stmt->fetchAll();

// Get recent jobs
$stmt = $pdo->query("SELECT j.id, j.title, u.name as employer_name, j.posted_date 
                     FROM jobs j 
                     JOIN users u ON j.employer_id = u.id 
                     ORDER BY j.posted_date DESC LIMIT 5");
$recent_jobs = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-danger text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-danger rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-shield-lock fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0">Admin Panel</h5>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="manage_users.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-people me-2"></i> Manage Users</a>
                        <a href="manage_jobs.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Manage Jobs</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <h3 class="fw-bold mb-4">Admin Dashboard</h3>

            <!-- Stats Boxes -->
            <div class="row g-4 mb-5">
                <div class="col-sm-6 col-lg-3">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body p-4 text-center">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                                <i class="bi bi-person fs-4"></i>
                            </div>
                            <h2 class="fw-bold mb-0"><?php echo $total_job_seekers; ?></h2>
                            <p class="text-muted small mb-0">Job Seekers</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body p-4 text-center">
                            <div class="bg-success bg-opacity-10 text-success rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                                <i class="bi bi-building fs-4"></i>
                            </div>
                            <h2 class="fw-bold mb-0"><?php echo $total_employers; ?></h2>
                            <p class="text-muted small mb-0">Employers</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body p-4 text-center">
                            <div class="bg-info bg-opacity-10 text-info rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                                <i class="bi bi-briefcase fs-4"></i>
                            </div>
                            <h2 class="fw-bold mb-0"><?php echo $total_jobs; ?></h2>
                            <p class="text-muted small mb-0">Total Jobs</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body p-4 text-center">
                            <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                                <i class="bi bi-file-earmark-text fs-4"></i>
                            </div>
                            <h2 class="fw-bold mb-0"><?php echo $total_applications; ?></h2>
                            <p class="text-muted small mb-0">Applications</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Recent Users -->
                <div class="col-lg-6 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white border-bottom-1 p-4 pb-3 d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0">Recent Users</h5>
                            <a href="manage_users.php" class="btn btn-sm btn-outline-secondary">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush">
                                <?php foreach ($recent_users as $user): ?>
                                    <li class="list-group-item p-3 border-bottom">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <div class="fw-bold text-dark"><?php echo htmlspecialchars($user['name']); ?></div>
                                                <small class="text-muted"><?php echo htmlspecialchars($user['email']); ?></small>
                                            </div>
                                            <span class="badge bg-<?php echo $user['role'] === 'employer' ? 'success' : 'primary'; ?> bg-opacity-10 text-<?php echo $user['role'] === 'employer' ? 'success' : 'primary'; ?> py-1 px-2 rounded-pill small">
                                                <?php echo ucfirst($user['role']); ?>
                                            </span>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Recent Jobs -->
                <div class="col-lg-6 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white border-bottom-1 p-4 pb-3 d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0">Recent Jobs</h5>
                            <a href="manage_jobs.php" class="btn btn-sm btn-outline-secondary">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush">
                                <?php foreach ($recent_jobs as $job): ?>
                                    <li class="list-group-item p-3 border-bottom">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <a href="../job_details.php?id=<?php echo $job['id']; ?>" class="fw-bold text-dark text-decoration-none d-block" target="_blank">
                                                    <?php echo htmlspecialchars($job['title']); ?>
                                                </a>
                                                <small class="text-muted">by <?php echo htmlspecialchars($job['employer_name']); ?></small>
                                            </div>
                                            <small class="text-muted border rounded px-2 py-1 bg-light"><?php echo date('M d', strtotime($job['posted_date'])); ?></small>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
