<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employer') {
    header("Location: ../login.php");
    exit();
}

$employer_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle Application Status Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['application_id']) && isset($_POST['status'])) {
    $app_id = (int)$_POST['application_id'];
    $new_status = $_POST['status'];
    
    $valid_statuses = ['pending', 'reviewed', 'accepted', 'rejected'];
    if (in_array($new_status, $valid_statuses)) {
        // Verify application belongs to a job owned by this employer
        $stmt = $pdo->prepare("SELECT a.id FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ? AND j.employer_id = ?");
        $stmt->execute([$app_id, $employer_id]);
        
        if ($stmt->fetch()) {
            try {
                $stmt = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ?");
                $stmt->execute([$new_status, $app_id]);
                $success = "Application status updated.";
            } catch (PDOException $e) {
                $error = "Failed to update status.";
            }
        } else {
            $error = "Unauthorized action.";
        }
    }
}

// Check if filtering by specific job
$job_filter = isset($_GET['job_id']) && is_numeric($_GET['job_id']) ? (int)$_GET['job_id'] : 0;
$status_filter = $_GET['status'] ?? '';

// Build query
$params = [$employer_id];
$query = "SELECT a.*, j.title as job_title, u.name as applicant_name, u.email as applicant_email, 
                 p.phone, p.skills, p.education, p.experience, r.file_path as resume_path 
          FROM applications a 
          JOIN jobs j ON a.job_id = j.id 
          JOIN users u ON a.user_id = u.id 
          LEFT JOIN profiles p ON u.id = p.user_id 
          JOIN resumes r ON a.resume_id = r.id 
          WHERE j.employer_id = ?";

if ($job_filter > 0) {
    $query .= " AND j.id = ?";
    $params[] = $job_filter;
}

if ($status_filter && in_array($status_filter, ['pending', 'reviewed', 'accepted', 'rejected'])) {
    $query .= " AND a.status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY a.applied_date DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$applicants = $stmt->fetchAll();

// Fetch jobs for filter dropdown
$stmt_jobs = $pdo->prepare("SELECT id, title FROM jobs WHERE employer_id = ? ORDER BY posted_date DESC");
$stmt_jobs->execute([$employer_id]);
$jobs_list = $stmt_jobs->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-dark text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-dark rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-building fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0 text-truncate" title="<?php echo htmlspecialchars($_SESSION['user_name']); ?>"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h5>
                        <small class="text-white-50">Employer Account</small>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="post_job.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-plus-circle me-2"></i> Post a Job</a>
                        <a href="manage_jobs.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Manage Jobs</a>
                        <a href="applicants.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-people me-2"></i> View Applicants</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <h3 class="fw-bold mb-4">Manage Applicants</h3>

            <!-- Filters -->
            <div class="card shadow-sm border-0 mb-4 bg-light">
                <div class="card-body p-3">
                    <form method="GET" action="" class="row g-2 align-items-center">
                        <div class="col-md-5">
                            <select name="job_id" class="form-select">
                                <option value="0">All Jobs</option>
                                <?php foreach ($jobs_list as $j): ?>
                                    <option value="<?php echo $j['id']; ?>" <?php echo $job_filter === $j['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($j['title']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <select name="status" class="form-select">
                                <option value="">All Statuses</option>
                                <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="reviewed" <?php echo $status_filter === 'reviewed' ? 'selected' : ''; ?>>Reviewed</option>
                                <option value="accepted" <?php echo $status_filter === 'accepted' ? 'selected' : ''; ?>>Accepted</option>
                                <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                        </div>
                    </form>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (empty($applicants)): ?>
                <div class="card shadow-sm border-0">
                    <div class="card-body p-5 text-center text-muted">
                        <i class="bi bi-people fs-1 d-block mb-3 text-muted"></i>
                        <h5 class="fw-bold text-dark">No Applicants Found</h5>
                        <p class="mb-0">Try adjusting your filters or <a href="post_job.php">post a new job</a> to get more applicants.</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="accordion shadow-sm" id="applicantsAccordion">
                    <?php foreach ($applicants as $index => $app): ?>
                        <div class="accordion-item border-0 border-bottom mb-2 rounded overflow-hidden">
                            <h2 class="accordion-header" id="heading<?php echo $app['id']; ?>">
                                <button class="accordion-button <?php echo $index !== 0 ? 'collapsed' : ''; ?> bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $app['id']; ?>" aria-expanded="<?php echo $index === 0 ? 'true' : 'false'; ?>">
                                    <div class="d-flex w-100 justify-content-between align-items-center me-3">
                                        <div class="d-flex align-items-center mt-1">
                                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px; font-weight: bold;">
                                                <?php echo strtoupper(substr($app['applicant_name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold text-dark mb-0 d-block fs-6"><?php echo htmlspecialchars($app['applicant_name']); ?></div>
                                                <small class="text-muted">Applied for: <span class="fw-medium"><?php echo htmlspecialchars($app['job_title']); ?></span></small>
                                            </div>
                                        </div>
                                        <div class="text-end">
                                            <div class="badge badge-status-<?php echo $app['status']; ?> py-1 px-2 rounded-pill shadow-sm mb-1" style="font-size: 0.70rem; letter-spacing: 0.5px;">
                                                <?php echo strtoupper($app['status']); ?>
                                            </div>
                                            <div class="text-muted d-block" style="font-size: 0.75rem;"><?php echo date('M d, Y', strtotime($app['applied_date'])); ?></div>
                                        </div>
                                    </div>
                                </button>
                            </h2>
                            <div id="collapse<?php echo $app['id']; ?>" class="accordion-collapse collapse <?php echo $index === 0 ? 'show' : ''; ?>" data-bs-parent="#applicantsAccordion">
                                <div class="accordion-body bg-light border-top p-4">
                                    <div class="row">
                                        <div class="col-md-7 mb-4 mb-md-0">
                                            <h6 class="fw-bold mb-3 border-bottom pb-2">Applicant Profile</h6>
                                            <div class="d-flex align-items-center mb-2">
                                                <i class="bi bi-envelope text-muted me-2"></i> 
                                                <a href="mailto:<?php echo htmlspecialchars($app['applicant_email']); ?>" class="text-decoration-none"><?php echo htmlspecialchars($app['applicant_email']); ?></a>
                                            </div>
                                            <div class="d-flex align-items-center mb-3">
                                                <i class="bi bi-telephone text-muted me-2"></i> 
                                                <span><?php echo !empty($app['phone']) ? htmlspecialchars($app['phone']) : '<em class="text-muted">Not provided</em>'; ?></span>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <strong class="text-muted d-block small mb-1">Skills:</strong>
                                                <div class="bg-white p-2 rounded border small"><?php echo !empty($app['skills']) ? nl2br(htmlspecialchars($app['skills'])) : '<em class="text-muted">Not provided</em>'; ?></div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <strong class="text-muted d-block small mb-1">Experience:</strong>
                                                <div class="bg-white p-2 rounded border small"><?php echo !empty($app['experience']) ? nl2br(htmlspecialchars($app['experience'])) : '<em class="text-muted">Not provided</em>'; ?></div>
                                            </div>
                                            
                                            <div>
                                                <strong class="text-muted d-block small mb-1">Education:</strong>
                                                <div class="bg-white p-2 rounded border small"><?php echo !empty($app['education']) ? nl2br(htmlspecialchars($app['education'])) : '<em class="text-muted">Not provided</em>'; ?></div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-5">
                                            <h6 class="fw-bold mb-3 border-bottom pb-2">Actions</h6>
                                            
                                            <!-- Resume Download -->
                                            <a href="../<?php echo htmlspecialchars($app['resume_path']); ?>" target="_blank" class="btn btn-outline-primary w-100 mb-4 d-flex align-items-center justify-content-center py-2 shadow-sm bg-white">
                                                <i class="bi bi-file-earmark-pdf fs-4 me-2 text-danger"></i> 
                                                <span class="fw-medium">View Resume</span>
                                            </a>
                                            
                                            <!-- Status Update Form -->
                                            <div class="bg-white p-3 rounded border">
                                                <strong class="text-muted d-block small mb-2">Update Status:</strong>
                                                <form method="POST" action="">
                                                    <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                                    <div class="mb-3">
                                                        <select name="status" class="form-select form-select-sm">
                                                            <option value="pending" <?php echo $app['status'] === 'pending' ? 'selected' : ''; ?>>Pending Decision</option>
                                                            <option value="reviewed" <?php echo $app['status'] === 'reviewed' ? 'selected' : ''; ?>>Reviewed</option>
                                                            <option value="accepted" <?php echo $app['status'] === 'accepted' ? 'selected' : ''; ?>>Accepted (Hire)</option>
                                                            <option value="rejected" <?php echo $app['status'] === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                                        </select>
                                                    </div>
                                                    <button type="submit" class="btn btn-sm btn-dark w-100">Save Status</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
