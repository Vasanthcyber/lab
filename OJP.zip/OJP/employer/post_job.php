<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employer') {
    header("Location: ../login.php");
    exit();
}

$employer_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle Job Creation or Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $salary = trim($_POST['salary'] ?? '');
    $job_type = trim($_POST['job_type'] ?? '');
    $action_id = isset($_POST['job_id']) && is_numeric($_POST['job_id']) ? (int)$_POST['job_id'] : 0;

    if (empty($title) || empty($description) || empty($location) || empty($job_type)) {
        $error = "Title, description, location, and job type are required.";
    } else {
        if ($action_id > 0) {
            // Update existing job
            // Check ownership first
            $stmt = $pdo->prepare("SELECT id FROM jobs WHERE id = ? AND employer_id = ?");
            $stmt->execute([$action_id, $employer_id]);
            if ($stmt->fetch()) {
                try {
                    $stmt = $pdo->prepare("UPDATE jobs SET title = ?, description = ?, location = ?, salary = ?, job_type = ? WHERE id = ?");
                    $stmt->execute([$title, $description, $location, $salary, $job_type, $action_id]);
                    $success = "Job updated successfully!";
                } catch (PDOException $e) {
                    $error = "Failed to update job.";
                }
            } else {
                $error = "Unauthorized action.";
            }
        } else {
            // Insert new job
            try {
                $stmt = $pdo->prepare("INSERT INTO jobs (employer_id, title, description, location, salary, job_type) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$employer_id, $title, $description, $location, $salary, $job_type]);
                $success = "Job posted successfully!";
                // Clear post data to show empty form
                $_POST = [];
            } catch (PDOException $e) {
                $error = "Failed to post job. " . $e->getMessage();
            }
        }
    }
}

// Check if editing an existing job
$job_to_edit = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM jobs WHERE id = ? AND employer_id = ?");
    $stmt->execute([$edit_id, $employer_id]);
    $job_to_edit = $stmt->fetch();
    if (!$job_to_edit) {
        $error = "Job not found or unauthorized.";
    }
}

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-dark text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-dark rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-building fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0 text-truncate" title="<?php echo htmlspecialchars($_SESSION['user_name']); ?>"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h5>
                        <small class="text-white-50">Employer Account</small>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="post_job.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-plus-circle me-2"></i> Post a Job</a>
                        <a href="manage_jobs.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Manage Jobs</a>
                        <a href="applicants.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-people me-2"></i> View Applicants</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white border-bottom-0 p-4 pb-0 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><?php echo $job_to_edit ? 'Edit Job Posting' : 'Post a New Job'; ?></h5>
                    <?php if ($job_to_edit): ?>
                        <a href="manage_jobs.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i> Cancel Edit</a>
                    <?php endif; ?>
                </div>
                <div class="card-body p-4">

                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($success); ?>
                            <?php if (!$job_to_edit): ?>
                                <a href="manage_jobs.php" class="alert-link ms-2">View your jobs</a>
                            <?php endif; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <?php if ($job_to_edit): ?>
                            <input type="hidden" name="job_id" value="<?php echo $job_to_edit['id']; ?>">
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-md-12 mb-4">
                                <label class="form-label fw-bold">Job Title <span class="text-danger">*</span></label>
                                <input type="text" name="title" class="form-control form-control-lg" required value="<?php echo htmlspecialchars($job_to_edit ? $job_to_edit['title'] : ($_POST['title'] ?? '')); ?>" placeholder="e.g. Senior Software Engineer">
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                                <input type="text" name="location" class="form-control" required value="<?php echo htmlspecialchars($job_to_edit ? $job_to_edit['location'] : ($_POST['location'] ?? '')); ?>" placeholder="e.g. New York, Remote, etc.">
                            </div>

                            <div class="col-md-6 mb-4">
                                <label class="form-label fw-bold">Job Type <span class="text-danger">*</span></label>
                                <?php $selected_type = $job_to_edit ? $job_to_edit['job_type'] : ($_POST['job_type'] ?? ''); ?>
                                <select name="job_type" class="form-select" required>
                                    <option value="" disabled <?php echo empty($selected_type) ? 'selected' : ''; ?>>Select Type</option>
                                    <option value="full-time" <?php echo $selected_type === 'full-time' ? 'selected' : ''; ?>>Full Time</option>
                                    <option value="part-time" <?php echo $selected_type === 'part-time' ? 'selected' : ''; ?>>Part Time</option>
                                    <option value="contract" <?php echo $selected_type === 'contract' ? 'selected' : ''; ?>>Contract</option>
                                    <option value="internship" <?php echo $selected_type === 'internship' ? 'selected' : ''; ?>>Internship</option>
                                    <option value="remote" <?php echo $selected_type === 'remote' ? 'selected' : ''; ?>>Remote / Freeelance</option>
                                </select>
                            </div>

                            <div class="col-md-12 mb-4">
                                <label class="form-label fw-bold">Salary Information <small class="text-muted fw-normal">(Optional)</small></label>
                                <input type="text" name="salary" class="form-control" value="<?php echo htmlspecialchars($job_to_edit ? $job_to_edit['salary'] : ($_POST['salary'] ?? '')); ?>" placeholder="e.g. $80,000 - $100,000 / year">
                            </div>

                            <div class="col-md-12 mb-4">
                                <label class="form-label fw-bold">Job Description <span class="text-danger">*</span></label>
                                <textarea name="description" class="form-control" rows="10" required placeholder="Describe the role, responsibilities, requirements, and benefits..."><?php echo htmlspecialchars($job_to_edit ? $job_to_edit['description'] : ($_POST['description'] ?? '')); ?></textarea>
                            </div>
                        </div>

                        <div class="d-grid mt-2">
                            <button type="submit" class="btn btn-primary btn-lg shadow-sm">
                                <?php echo $job_to_edit ? '<i class="bi bi-save me-2"></i> Update Job Posting' : '<i class="bi bi-send me-2"></i> Post Job Now'; ?>
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
