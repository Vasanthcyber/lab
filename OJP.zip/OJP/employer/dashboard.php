<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employer') {
    header("Location: ../login.php");
    exit();
}

$employer_id = $_SESSION['user_id'];

// Get posted jobs count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM jobs WHERE employer_id = ?");
$stmt->execute([$employer_id]);
$jobs_count = $stmt->fetchColumn();

// Get total applicants (excluding rejected)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM applications a JOIN jobs j ON a.job_id = j.id WHERE j.employer_id = ? AND a.status != 'rejected'");
$stmt->execute([$employer_id]);
$total_applicants = $stmt->fetchColumn();

// Get pending applications
$stmt = $pdo->prepare("SELECT COUNT(*) FROM applications a JOIN jobs j ON a.job_id = j.id WHERE j.employer_id = ? AND a.status = 'pending'");
$stmt->execute([$employer_id]);
$pending_applicants = $stmt->fetchColumn();

// Get recent jobs
$stmt = $pdo->prepare("SELECT * FROM jobs WHERE employer_id = ? ORDER BY posted_date DESC LIMIT 5");
$stmt->execute([$employer_id]);
$recent_jobs = $stmt->fetchAll();

// Get recent applications
$stmt = $pdo->prepare("SELECT a.*, j.title, u.name as applicant_name 
                       FROM applications a 
                       JOIN jobs j ON a.job_id = j.id 
                       JOIN users u ON a.user_id = u.id 
                       WHERE j.employer_id = ? 
                       ORDER BY a.applied_date DESC LIMIT 5");
$stmt->execute([$employer_id]);
$recent_applications = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-dark text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-dark rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-building fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0 text-truncate" title="<?php echo htmlspecialchars($_SESSION['user_name']); ?>"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h5>
                        <small class="text-white-50">Employer Account</small>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="post_job.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-plus-circle me-2"></i> Post a Job</a>
                        <a href="manage_jobs.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Manage Jobs</a>
                        <a href="applicants.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-people me-2"></i> View Applicants</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Employer Dashboard</h3>
                <a href="post_job.php" class="btn btn-primary shadow-sm"><i class="bi bi-plus-lg me-1"></i> Post New Job</a>
            </div>

            <!-- Stats Boxes -->
            <div class="row g-4 mb-5">
                <div class="col-md-4">
                    <div class="card shadow-sm border-0 border-start border-4 border-primary h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="text-muted text-uppercase fw-bold mb-0">Active Jobs</h6>
                                <div class="bg-primary bg-opacity-10 text-primary rounded p-2">
                                    <i class="bi bi-briefcase fs-4 lh-1"></i>
                                </div>
                            </div>
                            <h2 class="display-5 fw-bold text-dark mb-0"><?php echo $jobs_count; ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm border-0 border-start border-4 border-success h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="text-muted text-uppercase fw-bold mb-0">Total Applicants</h6>
                                <div class="bg-success bg-opacity-10 text-success rounded p-2">
                                    <i class="bi bi-people fs-4 lh-1"></i>
                                </div>
                            </div>
                            <h2 class="display-5 fw-bold text-dark mb-0"><?php echo $total_applicants; ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm border-0 border-start border-4 border-warning h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="text-muted text-uppercase fw-bold mb-0">Pending Review</h6>
                                <div class="bg-warning bg-opacity-10 text-warning rounded p-2">
                                    <i class="bi bi-clock-history fs-4 lh-1"></i>
                                </div>
                            </div>
                            <h2 class="display-5 fw-bold text-dark mb-0"><?php echo $pending_applicants; ?></h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Recent Jobs -->
                <div class="col-lg-6 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white border-0 p-4 pb-0 d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0">Recent Jobs Posted</h5>
                            <a href="manage_jobs.php" class="small text-decoration-none">View All</a>
                        </div>
                        <div class="card-body p-4">
                            <?php if (empty($recent_jobs)): ?>
                                <div class="text-center py-4 text-muted border border-dashed rounded bg-light">
                                    No jobs posted yet. <br>
                                    <a href="post_job.php" class="btn btn-sm btn-outline-primary mt-2">Post Your First Job</a>
                                </div>
                            <?php else: ?>
                                <ul class="list-group list-group-flush">
                                    <?php foreach ($recent_jobs as $job): ?>
                                        <li class="list-group-item px-0 py-3 border-bottom">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <a href="../job_details.php?id=<?php echo $job['id']; ?>" class="fw-bold text-dark text-decoration-none d-block mb-1" target="_blank">
                                                        <?php echo htmlspecialchars($job['title']); ?>
                                                    </a>
                                                    <small class="text-muted"><i class="bi bi-geo-alt me-1"></i> <?php echo htmlspecialchars($job['location']); ?></small>
                                                </div>
                                                <small class="text-muted border rounded px-2 py-1 bg-light"><?php echo date('M d', strtotime($job['posted_date'])); ?></small>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Recent Applications -->
                <div class="col-lg-6 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white border-0 p-4 pb-0 d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0">Recent Applications</h5>
                            <a href="applicants.php" class="small text-decoration-none">View All</a>
                        </div>
                        <div class="card-body p-4">
                            <?php if (empty($recent_applications)): ?>
                                <div class="text-center py-4 text-muted border border-dashed rounded bg-light">
                                    No applications received yet.
                                </div>
                            <?php else: ?>
                                <ul class="list-group list-group-flush">
                                    <?php foreach ($recent_applications as $app): ?>
                                        <li class="list-group-item px-0 py-3 border-bottom">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <div class="fw-bold text-dark d-block mb-1">
                                                        <?php echo htmlspecialchars($app['applicant_name']); ?>
                                                    </div>
                                                    <small class="text-muted d-block mb-2"> Applied for: <span class="fw-medium text-dark"><?php echo htmlspecialchars($app['title']); ?></span></small>
                                                    <span class="badge badge-status-<?php echo $app['status']; ?> py-1 px-2 rounded-pill shadow-sm" style="font-size: 0.70rem; letter-spacing: 0.5px;">
                                                        <?php echo strtoupper($app['status']); ?>
                                                    </span>
                                                </div>
                                                <a href="applicants.php?job_id=<?php echo $app['job_id']; ?>" class="btn btn-sm btn-light border"><i class="bi bi-chevron-right"></i></a>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
