<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employer') {
    header("Location: ../login.php");
    exit();
}

$employer_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle Job Deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];
    
    // Authorization check
    $stmt = $pdo->prepare("SELECT id FROM jobs WHERE id = ? AND employer_id = ?");
    $stmt->execute([$delete_id, $employer_id]);
    if ($stmt->fetch()) {
        try {
            // Because of ON DELETE CASCADE, deleting a job will also delete related applications
            $stmt = $pdo->prepare("DELETE FROM jobs WHERE id = ?");
            $stmt->execute([$delete_id]);
            $success = "Job deleted successfully.";
        } catch (PDOException $e) {
            $error = "Failed to delete job.";
        }
    } else {
        $error = "Unauthorized action.";
    }
}

// Fetch all jobs by this employer
$stmt = $pdo->prepare("
    SELECT j.*, 
           COUNT(a.id) as total_applicants,
           SUM(CASE WHEN a.status = 'pending' THEN 1 ELSE 0 END) as pending_applicants
    FROM jobs j 
    LEFT JOIN applications a ON j.id = a.job_id 
    WHERE j.employer_id = ? 
    GROUP BY j.id 
    ORDER BY j.posted_date DESC
");
$stmt->execute([$employer_id]);
$jobs = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="p-4 bg-dark text-white text-center rounded-top">
                        <div class="d-inline-flex justify-content-center align-items-center bg-white text-dark rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-building fs-2"></i>
                        </div>
                        <h5 class="fw-bold mb-0 text-truncate" title="<?php echo htmlspecialchars($_SESSION['user_name']); ?>"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h5>
                        <small class="text-white-50">Employer Account</small>
                    </div>
                    <div class="list-group list-group-flush sidebar">
                        <a href="dashboard.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                        <a href="post_job.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-plus-circle me-2"></i> Post a Job</a>
                        <a href="manage_jobs.php" class="list-group-item list-group-item-action active border-0 px-4 py-3"><i class="bi bi-briefcase me-2"></i> Manage Jobs</a>
                        <a href="applicants.php" class="list-group-item list-group-item-action border-0 px-4 py-3"><i class="bi bi-people me-2"></i> View Applicants</a>
                        <a href="../logout.php" class="list-group-item list-group-item-action border-0 px-4 py-3 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Manage Jobs</h3>
                <a href="post_job.php" class="btn btn-primary shadow-sm"><i class="bi bi-plus-lg me-1"></i> Post New Job</a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <?php if (empty($jobs)): ?>
                        <div class="p-5 text-center text-muted">
                            <i class="bi bi-briefcase fs-1 d-block mb-3 text-muted"></i>
                            <h5 class="fw-bold text-dark">No Jobs Posted Yet</h5>
                            <p class="mb-4">You haven't created any job listings. Start hiring today!</p>
                            <a href="post_job.php" class="btn btn-primary px-4"><i class="bi bi-plus-circle me-2"></i>Create Job Posting</a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light text-muted">
                                    <tr>
                                        <th class="px-4 py-3 border-0">Job Info</th>
                                        <th class="py-3 border-0 text-center">Applicants</th>
                                        <th class="py-3 border-0 text-center">Posted Date</th>
                                        <th class="px-4 py-3 border-0 text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($jobs as $job): ?>
                                        <tr>
                                            <td class="px-4 py-4">
                                                <a href="../job_details.php?id=<?php echo $job['id']; ?>" class="fw-bold text-dark text-decoration-none d-block mb-1" target="_blank">
                                                    <?php echo htmlspecialchars($job['title']); ?> <i class="bi bi-box-arrow-up-right ms-1 small text-muted"></i>
                                                </a>
                                                <span class="badge bg-light text-dark border me-1"><?php echo htmlspecialchars(ucwords(str_replace('-', ' ', $job['job_type']))); ?></span>
                                                <span class="small text-muted"><i class="bi bi-geo-alt ms-2 me-1"></i> <?php echo htmlspecialchars($job['location']); ?></span>
                                            </td>
                                            <td class="py-4 text-center">
                                                <span class="fs-5 fw-bold text-primary"><?php echo $job['total_applicants']; ?></span>
                                                <?php if ($job['pending_applicants'] > 0): ?>
                                                    <span class="badge bg-warning text-dark ms-1" title="Pending Reviews"><?php echo $job['pending_applicants']; ?> New</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="py-4 text-center text-muted">
                                                <?php echo date('M d, Y', strtotime($job['posted_date'])); ?>
                                            </td>
                                            <td class="px-4 py-4 text-end">
                                                <div class="btn-group shadow-sm">
                                                    <a href="applicants.php?job_id=<?php echo $job['id']; ?>" class="btn btn-sm btn-outline-primary" title="View Applicants"><i class="bi bi-people"></i></a>
                                                    <a href="post_job.php?edit=<?php echo $job['id']; ?>" class="btn btn-sm btn-outline-secondary" title="Edit Job"><i class="bi bi-pencil"></i></a>
                                                    <a href="?delete=<?php echo $job['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this job? All associated applications will also be deleted.');" title="Delete Job"><i class="bi bi-trash"></i></a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
