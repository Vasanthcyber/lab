<?php
require_once 'includes/db.php';
include 'includes/header.php';

// Pagination settings
$limit = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Search filters
$search = trim($_GET['search'] ?? '');
$location = trim($_GET['location'] ?? '');
$type = trim($_GET['type'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if ($search) {
    $where_clauses[] = "(j.title LIKE ? OR j.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($location) {
    $where_clauses[] = "j.location LIKE ?";
    $params[] = "%$location%";
}

if ($type) {
    $where_clauses[] = "j.job_type = ?";
    $params[] = $type;
}

$where_sql = implode(" AND ", $where_clauses);

// Count total jobs for pagination
$count_sql = "SELECT COUNT(*) FROM jobs j WHERE $where_sql";
$stmt_count = $pdo->prepare($count_sql);
$stmt_count->execute($params);
$total_jobs = $stmt_count->fetchColumn();
$total_pages = ceil($total_jobs / $limit);

// Fetch jobs
$sql = "SELECT j.*, u.name as employer_name FROM jobs j 
        JOIN users u ON j.employer_id = u.id 
        WHERE $where_sql 
        ORDER BY j.posted_date DESC LIMIT $offset, $limit";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$jobs = $stmt->fetchAll();
?>

<div class="container py-5">
    <div class="row mb-5">
        <div class="col-12">
            <h2 class="fw-bold mb-4">Browse Jobs</h2>
            
            <!-- Search Form -->
            <div class="card shadow-sm border-0 mb-4 bg-light">
                <div class="card-body p-4">
                    <form action="jobs.php" method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label text-muted small fw-bold">Keywords</label>
                            <input type="text" name="search" class="form-control py-2" value="<?php echo htmlspecialchars($search); ?>" placeholder="Job title or keywords">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label text-muted small fw-bold">Location</label>
                            <input type="text" name="location" class="form-control py-2" value="<?php echo htmlspecialchars($location); ?>" placeholder="City, state, etc.">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted small fw-bold">Job Type</label>
                            <select name="type" class="form-select py-2">
                                <option value="">All Types</option>
                                <option value="full-time" <?php echo $type === 'full-time' ? 'selected' : ''; ?>>Full Time</option>
                                <option value="part-time" <?php echo $type === 'part-time' ? 'selected' : ''; ?>>Part Time</option>
                                <option value="contract" <?php echo $type === 'contract' ? 'selected' : ''; ?>>Contract</option>
                                <option value="internship" <?php echo $type === 'internship' ? 'selected' : ''; ?>>Internship</option>
                                <option value="remote" <?php echo $type === 'remote' ? 'selected' : ''; ?>>Remote</option>
                            </select>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100 py-2"><i class="bi bi-search"></i></button>
                        </div>
                    </form>
                </div>
            </div>
            
            <p class="text-muted mb-4">Showing <?php echo $total_jobs > 0 ? $offset + 1 : 0; ?> - <?php echo min($offset + $limit, $total_jobs); ?> of <?php echo $total_jobs; ?> jobs</p>
            
            <!-- Job List -->
            <div class="row g-4">
                <?php if (empty($jobs)): ?>
                    <div class="col-12 text-center py-5">
                        <h4 class="text-muted">No jobs found matching your criteria.</h4>
                        <a href="jobs.php" class="btn btn-outline-primary mt-3">Clear Filters</a>
                    </div>
                <?php else: ?>
                    <?php foreach ($jobs as $job): ?>
                        <div class="col-12">
                            <div class="card job-card border-0 rounded-3">
                                <div class="card-body p-4">
                                    <div class="row align-items-center">
                                        <div class="col-md-8 mb-3 mb-md-0">
                                            <h4 class="fw-bold text-dark text-decoration-none d-block mb-1">
                                                <a href="job_details.php?id=<?php echo $job['id']; ?>" class="text-dark text-decoration-none hover-primary">
                                                    <?php echo htmlspecialchars($job['title']); ?>
                                                </a>
                                            </h4>
                                            <div class="d-flex flex-wrap gap-3 text-muted small mb-2">
                                                <span><i class="bi bi-building"></i> <?php echo htmlspecialchars($job['employer_name']); ?></span>
                                                <span><i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($job['location']); ?></span>
                                            </div>
                                            <div class="d-flex flex-wrap gap-2 mt-3">
                                                <span class="badge bg-primary bg-opacity-10 text-primary py-1 px-2 rounded">
                                                    <?php echo htmlspecialchars(ucwords(str_replace('-', ' ', $job['job_type']))); ?>
                                                </span>
                                                <?php if (!empty($job['salary'])): ?>
                                                    <span class="badge bg-success bg-opacity-10 text-success py-1 px-2 rounded">
                                                        <?php echo htmlspecialchars($job['salary']); ?>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4 text-md-end">
                                            <p class="text-muted small mb-3">Posted: <?php echo date('M d, Y', strtotime($job['posted_date'])); ?></p>
                                            <a href="job_details.php?id=<?php echo $job['id']; ?>" class="btn btn-outline-primary px-4">View & Apply</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav class="mt-5">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&location=<?php echo urlencode($location); ?>&type=<?php echo urlencode($type); ?>">Previous</a>
                        </li>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo $page === $i ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&location=<?php echo urlencode($location); ?>&type=<?php echo urlencode($type); ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&location=<?php echo urlencode($location); ?>&type=<?php echo urlencode($type); ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
