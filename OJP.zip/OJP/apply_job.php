<?php
session_start();
require_once 'includes/db.php';

// Check if user is logged in and is a job seeker
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php");
    exit();
}

$job_id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id = $_SESSION['user_id'];

if (!$job_id) {
    header("Location: jobs.php");
    exit();
}

$error = '';
$success = '';

// Check if profile is complete
$stmt = $pdo->prepare("SELECT * FROM profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();
$profile_complete = !empty($profile['phone']) && !empty($profile['skills']) && !empty($profile['education']);

// Check if user has uploaded resumes
$stmt = $pdo->prepare("SELECT * FROM resumes WHERE user_id = ? ORDER BY uploaded_at DESC");
$stmt->execute([$user_id]);
$resumes = $stmt->fetchAll();

// Check if user already applied
$stmt = $pdo->prepare("SELECT id FROM applications WHERE job_id = ? AND user_id = ?");
$stmt->execute([$job_id, $user_id]);
$already_applied = $stmt->fetch();

if ($already_applied) {
    header("Location: user/applied_jobs.php");
    exit();
}

// Fetch job details
$stmt = $pdo->prepare("SELECT j.title, u.name as employer_name FROM jobs j JOIN users u ON j.employer_id = u.id WHERE j.id = ?");
$stmt->execute([$job_id]);
$job = $stmt->fetch();

if (!$job) {
    header("Location: jobs.php");
    exit();
}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$profile_complete) {
        $error = "Please complete your profile details before applying.";
    } elseif (empty($resumes)) {
        $error = "Please upload a resume before applying.";
    } else {
        $resume_id = isset($_POST['resume_id']) && is_numeric($_POST['resume_id']) ? (int)$_POST['resume_id'] : 0;
        
        // Vefify resume belongs to user
        $valid_resume = false;
        foreach ($resumes as $r) {
            if ($r['id'] === $resume_id) {
                $valid_resume = true;
                break;
            }
        }
        
        if (!$valid_resume) {
            $error = "Invalid resume selected.";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO applications (job_id, user_id, resume_id, status) VALUES (?, ?, ?, 'pending')");
                $stmt->execute([$job_id, $user_id, $resume_id]);
                $success = "Application submitted successfully!";
            } catch (PDOException $e) {
                $error = "An error occurred while submitting your application. Please try again.";
            }
        }
    }
}

include 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card shadow border-0 rounded-3">
                <div class="card-header bg-white border-bottom-0 p-4 pb-0">
                    <h4 class="fw-bold mb-1">Apply for Job</h4>
                    <p class="text-muted mb-0">Submit your application for <span class="fw-bold text-dark"><?php echo htmlspecialchars($job['title']); ?></span> at <span class="fw-bold text-dark"><?php echo htmlspecialchars($job['employer_name']); ?></span></p>
                </div>
                <div class="card-body p-4">

                    <?php if ($success): ?>
                        <div class="alert alert-success text-center py-4 rounded-3 border-0 bg-success bg-opacity-10 text-success shadow-sm mb-0">
                            <i class="bi bi-check-circle-fill fs-1 d-block mb-3"></i>
                            <h5 class="fw-bold"><?php echo htmlspecialchars($success); ?></h5>
                            <p class="mb-4">The employer has received your application.</p>
                            <a href="user/applied_jobs.php" class="btn btn-success px-4">View My Applications</a>
                        </div>
                    <?php else: ?>

                        <?php if ($error): ?>
                            <div class="alert alert-danger shadow-sm border-0 d-flex align-items-center mb-4">
                                <i class="bi bi-exclamation-octagon-fill fs-4 me-3"></i>
                                <div><?php echo htmlspecialchars($error); ?></div>
                            </div>
                        <?php endif; ?>

                        <?php if (!$profile_complete || empty($resumes)): ?>
                            <div class="alert alert-warning border border-warning text-dark mb-4 p-4">
                                <h6 class="fw-bold border-bottom border-warning pb-2 mb-3"><i class="bi bi-shield-exclamation me-2"></i> Action Required</h6>
                                <p class="mb-2">Before you can apply for this job, you need to:</p>
                                <ul class="mb-0">
                                    <?php if (!$profile_complete): ?><li><a href="user/edit_profile.php" class="alert-link">Complete your profile details</a> (skills, education, etc.)</li><?php endif; ?>
                                    <?php if (empty($resumes)): ?><li><a href="user/profile.php" class="alert-link">Upload at least one resume</a></li><?php endif; ?>
                                </ul>
                            </div>
                            <div class="d-grid gap-2">
                                <a href="user/dashboard.php" class="btn btn-outline-secondary py-2">Go to Dashboard</a>
                            </div>
                        <?php else: ?>
                            <form method="POST" action="">
                                <div class="mb-4 bg-light p-3 rounded border">
                                    <label class="form-label fw-bold text-dark mb-3">Select Resume to send <span class="text-danger">*</span></label>
                                    <?php foreach ($resumes as $index => $resume): ?>
                                        <div class="form-check custom-radio-box mb-2 p-3 bg-white border rounded">
                                            <input class="form-check-input ms-1 me-3 mt-2" type="radio" name="resume_id" id="resume_<?php echo $resume['id']; ?>" value="<?php echo $resume['id']; ?>" <?php echo $index === 0 ? 'checked' : ''; ?> required>
                                            <label class="form-check-label w-100 d-flex flex-column" for="resume_<?php echo $resume['id']; ?>" style="cursor: pointer;">
                                                <span class="fw-medium text-dark">
                                                    <i class="bi bi-file-earmark-pdf text-danger me-2"></i>
                                                    <?php 
                                                        $filename = basename($resume['file_path']);
                                                        echo htmlspecialchars(preg_replace('/^resume_[^_]+_/', 'Resume_', $filename)); 
                                                    ?>
                                                </span>
                                                <small class="text-muted ms-4">Uploaded on <?php echo date('M d, Y', strtotime($resume['uploaded_at'])); ?></small>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="alert alert-info py-2 small mb-4">
                                    <i class="bi bi-info-circle me-1"></i> Your full profile details (contact info, skills, education) will also be shared with the employer.
                                </div>
                                <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                                    <a href="job_details.php?id=<?php echo $job_id; ?>" class="btn btn-light border px-4">Cancel</a>
                                    <button type="submit" class="btn btn-primary px-4 fw-medium"><i class="bi bi-send me-2"></i> Submit Application</button>
                                </div>
                            </form>
                        <?php endif; ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
